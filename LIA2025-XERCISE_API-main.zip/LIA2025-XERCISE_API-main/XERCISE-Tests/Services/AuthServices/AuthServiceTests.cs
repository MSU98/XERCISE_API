﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using xerciseAPI.Models.DTOs;
using xerciseAPI.Services.AuthServices;

namespace XERCISE_Tests.Services.AuthServices
{
    public class AuthServiceTests
    {
        private readonly IConfiguration _mockConfig;
        private AuthService sut;

        public AuthServiceTests()
        {
            var inMemorySettings = new Dictionary<string, string>
            {
                {"Jwt:Key", "super_secret_test_key_1234567890"},
                {"Jwt:Issuer", "test-issuer"},
                {"Jwt:Audience", "test-audience"}
            };

            _mockConfig = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings!)
                .Build();

            sut = new AuthService(_mockConfig);
        }

        [Fact]
        public void CreateTokenReturnsJwtToken()
        {
            //Arrange
            UserResponse user = new UserResponse()
            {
                ObjectId = "user-123",
                Name = "Nils",
                Email = "nils@manpower.se"
            };

            //Act
            var token = sut.CreateToken(user);

            //Assert
            Assert.False(string.IsNullOrEmpty(token));
        }

        [Fact]
        public void CreateTokenReturnsJwtTokenWithCorrectClaims()
        {
            //Arrange
            UserResponse user = new UserResponse()
            {
                ObjectId = "user-123",
                Name = "Nils",
                Email = "nils@manpower.se"
            };

            //Act
            var token = sut.CreateToken(user);

            var tokenHandler = new JwtSecurityTokenHandler();
            var validationParams = GetValidationParams(_mockConfig["Jwt:Key"]!, validateLifetime: false);

            //Assert
            tokenHandler.ValidateToken(token, validationParams, out var validatedToken);
            var jwtToken = (JwtSecurityToken)validatedToken;

            Assert.Equal("user-123", jwtToken.Claims.First(c => c.Type == ClaimTypes.NameIdentifier).Value);
        }

        [Fact]
        public void TokenShouldBeInvalidIfKeyIsWrong()
        {
            //Arrange
            UserResponse user = new UserResponse()
            {
                ObjectId = "fel-123",
                Name = "Lurifax",
                Email = "Lurifax@manpower.se"
            };

            //Act
            var token = sut.CreateToken(user);
            var tokenHandler = new JwtSecurityTokenHandler();
            var wrongParams = GetValidationParams("Wrong_key_123_that_is_still_wrong_123", validateLifetime: false);

            //Assert
            var exception = Record.Exception(() =>
            {
                tokenHandler.ValidateToken(token, wrongParams, out _);
            });

            Assert.NotNull(exception);
            Assert.IsAssignableFrom<SecurityTokenException>(exception);
        }

        [Fact]
        public void Token_ShouldBeInvalid_IfExpired()
        {
            // Arrange: manually build an expired token
            var claims = new[]
            {
            new Claim(ClaimTypes.NameIdentifier, "old-user")
        };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_mockConfig["Jwt:Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var expiredToken = new JwtSecurityToken(
                issuer: _mockConfig["Jwt:Issuer"],
                audience: _mockConfig["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddSeconds(-5), // already expired
                signingCredentials: creds
            );

            var tokenString = new JwtSecurityTokenHandler().WriteToken(expiredToken);
            var validationParams = GetValidationParams(_mockConfig["Jwt:Key"]!, validateLifetime: true);

            // Act & Assert
            Assert.Throws<SecurityTokenExpiredException>(() =>
            {
                new JwtSecurityTokenHandler().ValidateToken(tokenString, validationParams, out _);
            });
        }


        private TokenValidationParameters GetValidationParams(string key, bool validateLifetime)
        {
            return new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = _mockConfig["Jwt:Issuer"],

                ValidateAudience = true,
                ValidAudience = _mockConfig["Jwt:Audience"],

                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)),

                ValidateLifetime = validateLifetime,
                ClockSkew = TimeSpan.Zero
            };
        }
    }
}
