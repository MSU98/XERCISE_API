﻿using Microsoft.EntityFrameworkCore;
using xerciseAPI.Models;
using xerciseAPI.Models.DTOs;
using xerciseAPI.Services.CategoryServices;
using xerciseAPI.Extensions;
using xerciseAPI.Services.StepGoalServices;

namespace XERCISE_Tests.Services.CategoryServices
{
    public class CategoryServiceTests : IDisposable
    {
        private readonly TestDb _db;
        private readonly CategoryService _sut;
        public CategoryServiceTests()
        {
            _db = new TestDb(
                new DbContextOptionsBuilder<TestDb>()
                .UseInMemoryDatabase(databaseName: "CategoryTestDb")
                .Options);

            var category1 = new Category() { Id = 1, WorkoutCategory = "Cardio" };
            var category2 = new Category() { Id = 2, WorkoutCategory = "StrengthTraining" };
            _db.Categories.Add(category1);
            _db.Categories.Add(category2);

            _db.SaveChanges();

            _sut = new CategoryService(_db);
        }

        public void Dispose()
        {
            _db.Database.EnsureDeleted();
            _db.Dispose();
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  GetAllCategories
        ----------------------------------------------------------------------------------------------------------------------------*/

        [Fact]
        public void GetAllCategoriesShouldReturnAllExistingCategories()
        {
            //Act
            int expected = _db.Categories.ToList().Count;
            var categories = _sut.GetAllCategories();

            //Assert
            Assert.Equal(expected, categories.Count);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  GetCategoryById
        ----------------------------------------------------------------------------------------------------------------------------*/

        [Theory]
        [InlineData(1, "Cardio")]
        [InlineData(2, "StrengthTraining")]
        public void GetCategoryByIdShouldReturnCorrectCategory(int id, string expected)
        {
            //Act
            var category = _sut.GetCategoryById(id);

            //Assert
            Assert.Equal(expected, category.WorkoutCategory);
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-32)]
        [InlineData(3)]
        public void GetCategoryByIdShouldReturnNullWithIncorrectId(int id)
        {
            //Act
            var category = _sut.GetCategoryById(id);

            //Assert
            Assert.Null(category);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  CreateCategory
        ----------------------------------------------------------------------------------------------------------------------------*/

        [Fact]
        public async Task CreateCategoryShouldReturnTrueWhenCreationIsSuccessful()
        {
            //Arrange
            string workoutCategory = "Dancing";
            int expectedCount = 3;

            //Act
            var result = await _sut.CreateCategory(workoutCategory);
            int actualCount = _db.Categories.Count();

            //Assert
            Assert.True(result);
            Assert.Equal(expectedCount, actualCount);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData("012345678901234567890123456789012345678901234567890")]
        [InlineData(null)]
        public async Task CreateCategoryShouldReturnFalseWhenValidationFails(string? workoutCategory)
        {
            //Act
            var result = await _sut.CreateCategory(workoutCategory!);

            //Assert
            Assert.False(result);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                          DeleteCategory
        ----------------------------------------------------------------------------------------------------------------------------*/

        [Fact]
        public async Task DeleteCategoryShouldReturnTrueWhenDeletionIsSuccessful()
        {
            //Arrange
            int categoryId = 1;

            //Act
            var result = await _sut.DeleteCategory(categoryId);

            //Assert
            Assert.True(result);
            Assert.DoesNotContain(_db.Categories.ToList(), c => c.Id == categoryId);
        }

        [Theory]
        [InlineData(int.MaxValue)]
        [InlineData(int.MinValue)]
        [InlineData(0)]
        [InlineData(-32)]
        [InlineData(3)]
        public async Task DeleteCategoryShouldReturnFalseWhenCategoryIdIsWrong(int categoryId)
        {
            //Act
            var result = await _sut.DeleteCategory(categoryId);

            //Assert
            Assert.False(result);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  UpdateCategory
        ----------------------------------------------------------------------------------------------------------------------------*/

        [Fact]
        public async Task UpdateCategoryShouldReturnTrueWhenInputIsValid()
        {
            //Arrange
            string workoutCategory = "Dancing";

            //Act
            var result = await _sut.UpdateCategory(1, workoutCategory);

            //Assert
            Assert.True(result);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        [InlineData("012345678901234567890123456789012345678901234567890")]
        public async Task UpdateCategoryShouldReturnFalseWithInvalidStringInput(string? workoutCategory)
        {
            //Act
            var result = await _sut.UpdateCategory(1, workoutCategory!);

            //Assert
            Assert.False(result);
        }

        [Theory]
        [InlineData(int.MaxValue)]
        [InlineData(int.MinValue)]
        [InlineData(0)]
        [InlineData(-32)]
        [InlineData(3)]
        public async Task UpdateCategoryShouldReturnFalseWithInvalidId(int categoryId)
        {
            //Act
            var result = await _sut.UpdateCategory(categoryId, "Dancing");

            //Assert
            Assert.False(result);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  ConvertToCategoryDTO
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public void ConvertToCategoryDTOShouldReturnACategoryDTO()
        {
            //Arrange
            var category = _db.Categories.FirstOrDefault();
            //Act
            var categoryDTO = category!.ToDto();

            //Assert

            Assert.IsType<CategoryDTO>(categoryDTO);

        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  ConvertToCategoryDTOList
        ----------------------------------------------------------------------------------------------------------------------------*/

        [Fact]
        public void ConvertToCategoryDTOListShouldReturnAListOfCategoryDTO()
        {
            //Arrange
            var categoryList = _db.Categories.ToList();
            //Act
            var categoryDTOList = categoryList.ToDtoList();

            //Assert
            Assert.Equal(categoryList.Count, categoryDTOList.Count);
            foreach (var categoryDTO in categoryDTOList)
            {
                Assert.IsType<CategoryDTO>(categoryDTO);
            }
        }
    }
}
