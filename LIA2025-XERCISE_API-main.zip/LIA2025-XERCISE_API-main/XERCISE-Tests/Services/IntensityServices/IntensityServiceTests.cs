﻿using Microsoft.EntityFrameworkCore;
using xerciseAPI.Extensions;
using xerciseAPI.Models;
using xerciseAPI.Models.DTOs;
using xerciseAPI.Services.CategoryServices;
using xerciseAPI.Services.IntensityServices;

namespace XERCISE_Tests.Services.IntensityServices
{
    public class IntensityServiceTests : IDisposable
    {
        private readonly TestDb _db;
        private readonly IntensityService _sut;
        public IntensityServiceTests()
        {
            _db = new TestDb(
                new DbContextOptionsBuilder<TestDb>()
                .UseInMemoryDatabase(databaseName: "IntensityTestDb")
                .Options);

            var intensity1 = new Intensity() { Id = 1, IntensityGrade = "Light" };
            var intensity2 = new Intensity() { Id = 2, IntensityGrade = "Medium" };
            _db.Intensities.Add(intensity1);
            _db.Intensities.Add(intensity2);

            _db.SaveChanges();

            _sut = new IntensityService(_db);
        }
        public void Dispose()
        {
            _db.Database.EnsureDeleted();
            _db.Dispose();
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  GetAllIntensities
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public void GetAllIntensitiesShouldReturnAllExistingIntensities()
        {
            //Act
            int expected = _db.Intensities.ToList().Count();
            var intensities = _sut.GetAllIntensities();

            //Assert
            Assert.Equal(expected, intensities.Count);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  GetIntensityById
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Theory]
        [InlineData(1, "Light")]
        [InlineData(2, "Medium")]
        public void GetIntensityByIdShouldReturnAnIntensityWithCorrectIdInput(int intensityId, string expected)
        {
            //Act
            var intensity = _sut.GetIntensityById(intensityId);

            //Assert
            Assert.Equal(expected, intensity!.IntensityGrade);
        }

        [Theory]
        [InlineData(-1)]
        [InlineData(0)]
        [InlineData(3)]
        public void GetIntensityByIdSHouldReturnNullWhenIdIsIncorrect(int intensityId)
        {
            //Act
            var intensity = _sut.GetIntensityById(intensityId);

            //Assert
            Assert.Null(intensity);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  CreateIntensity
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public async Task CreateIntensityShouldReturnTrueWhenCreationIsSuccessful()
        {
            //Act
            var result = await _sut.CreateIntensity("High");

            //Assert
            Assert.True(result);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        [InlineData("012345678901234567890123456789012345678901234567890")]
        public async Task CreateIntensityShouldReturnFalseWhenValidationFails(string? intensityGrade)
        {
            //Act
            var result = await _sut.CreateIntensity(intensityGrade!);

            //Assert
            Assert.False(result);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  DeleteIntensity
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public async Task DeleteIntensityShouldReturnTrueWhenDeletionIsSuccessful()
        {
            //Arrange
            int intensityId = 1;

            //Act
            var result = await _sut.DeleteIntensity(intensityId);

            //Assert
            Assert.True(result);
            Assert.DoesNotContain(_db.Intensities.ToList(), i => i.Id == intensityId);
        }

        [Theory]
        [InlineData(-14)]
        [InlineData(0)]
        [InlineData(3)]
        public async Task DeleteIntensityShouldReturnFalseWhenIdIsInvalid(int intensityId)
        {
            //Act
            bool result = await _sut.DeleteIntensity(intensityId);

            //Assert
            Assert.False(result);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  UpdateIntensity
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public async Task UpdateIntensityShouldReturnTrueWhenUpdateIsSuccessful()
        {
            //Arrange
            int intensityId = 1;
            string newIntensityGrade = "Very Medium";

            //Act
            var result = await _sut.UpdateIntensity(intensityId, newIntensityGrade);

            //Assert
            Assert.True(result);
        }

        [Theory]
        [InlineData(-32)]
        [InlineData(0)]
        [InlineData(3)]
        public async Task UpdateIntensityShouldReturnFalseWhenIdIsInvalid(int intensityId)
        {
            //Arrange
            string newIntensitygrade = "Very Medium";

            //Act
            var result = await _sut.UpdateIntensity(intensityId, newIntensitygrade);

            //Assert
            Assert.False(result);
        }

        [Theory]
        [InlineData("")]
        [InlineData(null)]
        [InlineData("012345678901234567890123456789012345678901234567890")]
        [InlineData(" ")]
        public async Task UpdateIntensityShouldReturnFalseWhenValidationFails(string? newIntensityGrade)
        {
            //Arrange
            int intensityId = 1;

            //Act
            var result = await _sut.UpdateIntensity(intensityId, newIntensityGrade!);

            //Assert
            Assert.False(result);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  ConvertToIntensityDTO
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public void ConvertToIntensityDTOShouldReturnAIntensityDTO()
        {
            //Arrange
            var intensity = _db.Intensities.First();

            //Act
            var actual = intensity.ToDto();

            //Assert
            Assert.IsType<IntensityDTO>(actual);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  ConvertToIntensityDTOList
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public void ConvertToIntensityDTOListShouldReturnAListOfIntensityDTOs()
        {
            //Arrange
            var intensityList = _db.Intensities.ToList();
            int expectedCount = _db.Intensities.Count();

            //Act
            var intensityDTOList = intensityList.ToDtoList();
            var actualCount = intensityDTOList.Count;

            //Assert
            Assert.Equal(expectedCount, actualCount);
            for (int i = 0; i < expectedCount; i++)
            {
                Assert.Equal(intensityList[i].Id, intensityDTOList[i].Id);
                Assert.IsType<IntensityDTO>(intensityDTOList[i]);
            }
        }

        [Fact]
        public void ConvertToIntensityDTOListSHouldReturnEmptyListIfUnputIsEmpty()
        {
            //Arrange
            var list = new List<Intensity>();

            //Act
            var actualList = list.ToDtoList();

            //Assert
            Assert.Empty(actualList);
        }
    }
}
