using Microsoft.EntityFrameworkCore;
using xerciseAPI.Models;
using xerciseAPI.Services.StepEntryServices;

namespace XERCISE_Tests.Services.StepEntryServices
{
    public class StepEntryServicesTests : IDisposable
    {
        private readonly TestDb _db;
        private readonly StepEntryService _sut;
        public StepEntryServicesTests()
        {
            _db = new TestDb(new DbContextOptionsBuilder<TestDb>().UseInMemoryDatabase(databaseName: "StepEntryTestDb").Options);
            var user1 = new User() { Id = 1, ObjectId = "1", Email = "Bella.Andersson@mail.com", Name = "Bella" };
            var user2 = new User() { Id = 2, ObjectId = "2", Email = "Hanna.Jonsson@mail.com", Name = "Hanna" };
            var user3 = new User() { Id = 3, ObjectId = "3", Email = "Leif.Persson@mail.com", Name = "Leif" };

            var steps1 = new StepEntry() { Id = 1, UserId = 1, Steps = 1, Date = new DateTime(2025, 05, 05, 0, 0, 0) };
            var steps2 = new StepEntry() { Id = 2, UserId = 2, Steps = 2, Date = new DateTime(2025, 06, 05, 0, 0, 0) };
            var steps3 = new StepEntry() { Id = 3, UserId = 3, Steps = 3, Date = new DateTime(2025, 07, 05, 0, 0, 0) };

            _db.Users.AddRange(user1, user2, user3);
            _db.StepEntries.AddRange(steps1, steps2, steps3);

            _db.SaveChanges();

            _sut = new StepEntryService(_db);
        }
        public void Dispose()
        {
            _db.Database.EnsureDeleted();
            _db.Dispose();
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                SaveStepEntry
       ----------------------------------------------------------------------------------------------------------------------------*/

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        [InlineData(-1000)]

        public async Task SaveStepEntryShouldReturnFalseWhenStepsIsZeroOrLess(int invalidSteps)
        {
            // Arrange
            var userObjectId = "1";
            var date = DateTime.Today;

            // Act
            var result = await _sut.SaveStepsOnDate(userObjectId, invalidSteps, date);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task SaveStepEntryShouldReturnFalseWhenUserObjectIdIsNull()
        {
            // Arrange
            var steps = 3000;
            var date = DateTime.Today;

            // Act
            var result = await _sut.SaveStepsOnDate(null!, steps, date);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task SaveStepEntryShouldReturnFalseWhenUserDoesNotExist()
        {
            // Arrange
            var steps = 3000;
            var date = DateTime.Today;

            // Act
            var result = await _sut.SaveStepsOnDate("999", steps, date);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task SaveStepsOnDateEntryShouldAddNewStepEntryWhenNoEntryExistForDate()
        {
            // Arrange
            var objectId = "1";
            var stepsToAdd = 1000;
            var date = new DateTime(2030, 01, 01);

            // Act
            var result = await _sut.SaveStepsOnDate(objectId, stepsToAdd, date);

            // Assert
            Assert.True(result);

            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == objectId);
            var entry = await _db.StepEntries.FirstOrDefaultAsync(s => s.UserId == user!.Id && s.Date == date);

            Assert.NotNull(entry);
            Assert.Equal(stepsToAdd, entry!.Steps);
        }

        [Fact]
        public async Task SaveStepsOnEntryDateShouldUpdateStepsWhenEntryAlreadyExistForDate()
        {
            // Arrange
            var objectId = "1";
            var date = new DateTime(2025, 05, 05);
            var additionalSteps = 100;

            // Act
            var result = await _sut.SaveStepsOnDate(objectId, additionalSteps, date);

            // Assert
            Assert.True(result);

            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == objectId);
            var entry = await _db.StepEntries.FirstOrDefaultAsync(s => s.UserId == user!.Id && s.Date == date);

            Assert.NotNull(entry);
            Assert.Equal(1 + additionalSteps, entry!.Steps);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                         GetSteps
       ----------------------------------------------------------------------------------------------------------------------------*/

        [Fact]
        public async Task GetStepsShouldReturnNullWhenObjectIdIsNull()
        {
            // Act
            var result = await _sut.GetSteps(null!, new DateTime(2025, 05, 05));

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStepsShouldReturnNullWhenUserDoesNotExist()
        {
            // Act
            var result = await _sut.GetSteps("does-not-exist", new DateTime(2025, 05, 05));

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStepsShouldReturnNullWhenStepEntryDoesNotExistForDate()
        {
            // Arrange
            var userObjectId = "1";
            var missingDate = new DateTime(2030, 01, 01);

            // Act
            var result = await _sut.GetSteps(userObjectId, missingDate);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStepsShouldReturnStepEntryDtoWhenEntryForDateExists()
        {
            // Arrange
            var userObjectId = "1";
            var date = new DateTime(2025, 05, 05);
           
            // Act
            var result = await _sut.GetSteps(userObjectId, date);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Steps);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                               DeleteSteps
       ----------------------------------------------------------------------------------------------------------------------------*/

        [Fact]
        public async Task DeleteStepsOnDateShouldReturnFalseWhenUserNotFound()
        {
            // Arrange
            var date = new DateTime(2025, 05, 05);

            // Act
            var result = await _sut.DeleteStepsOnDate("nonexistent", date);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task DeleteStepsOnDateShouldReturnFalseWhenNoEntryExistsForDate()
        {
            // Arrange
            var UserObjectId = "1";
            var missingDate = new DateTime(2020, 01, 01);

            // Act
            var result = await _sut.DeleteStepsOnDate(UserObjectId, missingDate);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task DeleteStepsOnDateShouldReturnTrueAndRemoveEntryWhenEntryExists()
        {
            // Arrange
            var userObjectId = "1";
            var entryDate = new DateTime(2025, 05, 05);

            // Act
            var results = await _sut.DeleteStepsOnDate(userObjectId, entryDate);

            // Assert
            Assert.True(results);

            var deleted = await _db.StepEntries.FirstOrDefaultAsync(s => s.Date == entryDate && s.User.ObjectId == userObjectId);

            Assert.Null(deleted);
        }
    }

}