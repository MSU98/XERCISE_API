﻿using Microsoft.EntityFrameworkCore;
using xerciseAPI.Models;
using xerciseAPI.Models.DTOs;
using xerciseAPI.Services.StepGoalServices;

namespace XERCISE_Tests.Services.StepGoalServices
{
    public class StepGoalServiceTests : IDisposable
    {
        private readonly TestDb _db;
        private readonly StepGoalService _sut;
        
        public StepGoalServiceTests()
        {
            _db = new TestDb(new DbContextOptionsBuilder<TestDb>().UseInMemoryDatabase(databaseName: "StepGoalTestDb").Options);
            var user1 = new User() { Id = 1, ObjectId = "1", Email = "Bella.Andersson@mail.com", Name = "Bella" };
            var user2 = new User() { Id = 2, ObjectId = "2", Email = "Hanna.Jonsson@mail.com", Name = "Hanna" };
            var user3 = new User() { Id = 3, ObjectId = "3", Email = "Leif.Persson@mail.com", Name = "Leif" };
            _db.Add(user1);
            _db.Add(user2);
            _db.Add(user3);

            var goal1 = new StepGoal() { Id = 1, Goal = 3000, UserId = 1 };
            var goal2 = new StepGoal() { Id = 2, Goal = 10000, UserId = 2 };

            _db.Add(goal1);
            _db.Add(goal2);

            _db.SaveChanges();

            _sut = new StepGoalService(_db);
        }
        public void Dispose()
        {
            _db.Database.EnsureDeleted();
            _db.Dispose();
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                SaveStepGoal
       ----------------------------------------------------------------------------------------------------------------------------*/

        [Theory]
        [InlineData(-1)]
        [InlineData(-1000)]
        public async Task SaveStepGoalShouldReturnFalseWhenStepGoalIsLessThanZero(int invalidGoal)
        {
            //Arrange
            var userObjectId = "1";
            //Act
            var result = await _sut.SaveStepGoal(userObjectId, invalidGoal);

            //Assert
            Assert.False(result);
        }

        [Fact]
        public async Task SaveStepGoalShouldReturnFalseWhenUserObjectIsNull()
        {
            //Arrange
            var setGoal = 2000;
            //Act
            var result = await _sut.SaveStepGoal(null!, setGoal);

            //Assert
            Assert.False(result);
        }

        [Fact]
        public async Task SaveStepGoalShouldCreateNewStepGoalWhenNoExistingGoal()
        {
            //Arrange
            var setGoal = 3000;
            var userObjectId = "3";

            //Act
            var result = await _sut.SaveStepGoal(userObjectId, setGoal);

            //Assert
            Assert.True(result);
        }

        [Fact]
        public async Task SaveStepGoalShouldUpdateExistingGoalWhenGoalExists()
        {
            //Arrange
            var userObjectId = "1";
            var newGoal = 5000;
            //Act
            var result = await _sut.SaveStepGoal(userObjectId, newGoal);

            //Assert
            Assert.True(result);
            var updated = await _sut.GetStepGoal(userObjectId);
            Assert.Equal(5000, updated!.Goal);
        }

        [Fact]
        public async Task SaveStepGoalShouldNotAddGoalWhenUserDoesNotExist()
        {
            // Arrange
            var userObjectId = "999";
            var setGoal = 3000;

            // Act
            var result = await _sut.SaveStepGoal(userObjectId, setGoal);

            // Assert
            Assert.False(result);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                GetStepGoal
       ----------------------------------------------------------------------------------------------------------------------------*/

        [Fact]
        public async Task GetStepGoalShouldReturnStepGoalWhenExists()
        {
            // Arrange
            var userObjectId = "2";
            var expected = 10000;

            // Act
            var result = await _sut.GetStepGoal(userObjectId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expected, result.Goal);
        }

        [Fact]
        public async Task GetStepGoalShouldReturnNullWhenNoGoalExists()
        {
            // Arrange
            var userObjectId = "999";

            // Act
            var result = await _sut.GetStepGoal(userObjectId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStepGoalShouldReturnNullWhenUserIdIsNull()
        {
            // Act
            var result = await _sut.GetStepGoal(null);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStepGoalShouldReturnStepGoalTypeOnValidEntry()
        {
            // Arrange
            var userObjectId = "1";

            // Act
            var result = await _sut.GetStepGoal(userObjectId);

            // Assert
            Assert.IsType<StepGoalDTO>(result);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                               DeleteStepGoal
       ----------------------------------------------------------------------------------------------------------------------------*/

        [Fact]
        public async Task DeleteStepGoalShouldReturnFalseWhenGoalDoesNotExist()
        {
            // Arrange
            var userObjectId = "999";

            // Act
            var result = await _sut.DeleteStepGoal(userObjectId);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task DeleteStepGoalShouldReturnFalseWhenUserIdIsNull()
        {
            // Act
            var result = await _sut.DeleteStepGoal(null);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task DeleteStepGoalShouldRemoveGoalAndReturnTrueWhenGoalExists()
        {
            // Arrange
            var userObjectId = "1";

            // Act
            var result = await _sut.DeleteStepGoal(userObjectId);

            // Assert
            Assert.True(result);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                       GetStepProgressByDate
        ----------------------------------------------------------------------------------------------------------------------------*/

        [Fact]
        public async Task GetStepProgressByDateShouldReturnNullWhenUserDoesNotExist()
        {
            // Arrange
            var invalidObjectId = "999";
            var date = DateTime.Today;

            // Act
            var result = await _sut.GetStepProgressByDate(invalidObjectId, date);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStepProgressByDateShouldReturnNullWhenObjectIdIsNull()
        {
            // Arrange
            string? objectId = null;
            var date = DateTime.Today;

            // Act
            var result = await _sut.GetStepProgressByDate(objectId!, date);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStepProgressByDateShouldReturnZeroWhenUserExistsButHasNoGoal()
        {
            // Arrange
            var objectId = "3";
            var user = await _db.Users.FirstAsync(u => u.ObjectId == objectId);
            var date = DateTime.Today;

            _db.StepEntries.Add(new StepEntry
            {
                Id = 100,
                UserId = user.Id,
                Steps = 4567,
                Date = date
            });

            await _db.SaveChangesAsync();

            // Act
            var result = await _sut.GetStepProgressByDate(objectId, date);

            // Assert
            Assert.Equal(4567, result.Steps);
            Assert.Equal(0, result.StepGoal);
        }

        [Fact]
        public async Task GetStepProgressByDateShouldReturnZeroWhenUserExistsButHasNoSteps()
        {
            // Arrange
            var objectId = "2";
            var date = DateTime.Today;

            // Act
            var result = await _sut.GetStepProgressByDate(objectId, date);

            // Assert
            Assert.Equal(0, result.Steps);
            Assert.Equal(10000, result.StepGoal);
        }

        [Fact]
        public async Task GetStepProgressByDateShouldReturnCorrectStepsAndGoalWhenDataExists()
        {
            // Arrange
            var objectId = "1";
            var user = await _db.Users.FirstAsync(u => u.ObjectId == objectId);
            var today = DateTime.Today;

            _db.StepEntries.Add(new StepEntry
            {
                Id = 1,
                UserId = user.Id,
                Steps = 5678,
                Date = today
            });

            await _db.SaveChangesAsync();

            // Act
            var result = await _sut.GetStepProgressByDate(objectId, today);

            // Assert
            Assert.Equal(5678, result.Steps);
            Assert.Equal(3000, result.StepGoal);
        }
    }
}
