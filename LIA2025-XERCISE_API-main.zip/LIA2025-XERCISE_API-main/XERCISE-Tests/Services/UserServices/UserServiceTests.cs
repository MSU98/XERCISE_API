﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using xerciseAPI.Extensions;
using xerciseAPI.Models;
using xerciseAPI.Models.DTOs;
using xerciseAPI.Services.CategoryServices;
using xerciseAPI.Services.UserService;
using xerciseAPI.Services.WorkoutServices;

namespace XERCISE_Tests.Services.UserServices
{
    public class UserServiceTests : IDisposable
    {
        private readonly TestDb _db;
        private string? objectId;
        private readonly UserService _sut;

        public UserServiceTests()
        {
            _db = new TestDb(
                new DbContextOptionsBuilder<TestDb>()
                .UseInMemoryDatabase(databaseName: "UserTestDb")
                .Options);

            var user1 = new User() { Id = 1, ObjectId = "1", Email = "hasse.aro@regionstockholm.se", Name = "Hasse" };
            var user2 = new User() { Id = 2, ObjectId = "2", Email = "nils.karlsson@pyssling.se", Name = "Nils" };
            var user3 = new User() { Id = 3, ObjectId = "3", Email = "Lasse.larssonson@syssling.se", Name = "Lasse" };

            _db.Users.Add(user1);
            _db.Users.Add(user2);
            _db.Users.Add(user3);

            _db.SaveChanges();

            _sut = new UserService(_db);
        }

        public void Dispose()
        {
            _db.Database.EnsureDeleted();
            _db.Dispose();
        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                                 CreateUser
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public async Task CreateUserShouldCreateAndSaveUserToDb()
        {
            //Arrange
            var user = new UserResponse()
            {
                ObjectId = "4",
                Email = "lisa.larsson@mail.se",
                Name = "Lisa"
            };

            //Act
            var createUser = await _sut.CreateUser(user);

            //Assert
            Assert.True(createUser);
        }

        [Theory]
        [InlineData("6", null, "Lasse")]
        [InlineData("7", "lasse.larsson@mail.se", null)]
        [InlineData("8", "", "Lars")]
        [InlineData("9", "", "LarsSomGillarAttSpelaWonderwallPåGitarrVarjeDag")]
        [InlineData("10", "Email@mail.se", "LarsSomGillarAttSpelaWonderwallPåGitarrLarsSoLarsSomGillarAttSpelaWonderwallPåGitarrVarjeDagmGillarAttSpelaWonderwallPåGitarrVarjeDagVarjeDag")]
        [InlineData("11", "Email", " ")]
        [InlineData("12", "LarsSomGillarAttSpelaWonderwallPåGitarrVarjeDLarsSomGillarAttSpelaWonderwallPåGitarrVarjeDagLarsSomGillarAttSpelaWonderwallPåGitarrVarjeDagLarsSomGillarAttSpelaWonderwallPåGitarrVarjeDagLarsSomGillarAttSpelaWonderwallPåGitarrVarjeDagLarsSomGillarAttSpelaWonderwallPåGitarrVarjeDagagLarsSomGillarAttSpelaWonderwallPåGitarrVarjeDag", " ")]
        public async Task CreateUserShouldReturnFalseWhenInputIsNull(string oId, string? email, string? fName)
        {
            //Arrange
            var user = new UserResponse()
            {
                ObjectId = oId,
                Email = email!,
                Name = fName!
            };

            //Act
            var createUser = await _sut.CreateUser(user);

            //Assert
            Assert.False(createUser);
        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                                DeleteUser
       ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public async Task DeleteUserShouldRemoveUser()
        {
            //Arrange
            var userId = 1;

            //Act
            var deletedUser = await _sut.DeleteUser(userId);

            //Assert
            Assert.True(deletedUser);
            Assert.DoesNotContain(_db.Users.ToList(), u => u.Id == userId);
        }
        [Theory]
        [InlineData(0)]
        [InlineData(-55)]
        [InlineData(5)]
        public async Task DeleteUserShouldReturnFalseWhenUserDoesNotExist(int userId)
        {
            //Act
            var actual = await _sut.DeleteUser(userId);

            //Assert
            Assert.False(actual);
        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                              GetAllUsers
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public async Task GetAllUsersShouldReturnListWithAllUsers()
        {
            //Arrange
            var expected = 3;

            //Act
            var users = await _sut.GetAllUsers();
            var actual = users?.Count;

            //Assert
            Assert.Equal(expected, actual);
        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                              GetUserById
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Theory]
        [InlineData("1", "Hasse")]
        [InlineData("3", "Lasse")]
        public async Task GetUserByIdShouldReturnCorrectUserThatMatchesId(string objectId, string expected)
        {
            //Act
            var actual = await _sut.GetUserById(objectId);

            //Assert
            Assert.Equal(expected, actual!.Name);
        }


        [Theory]
        [InlineData("-45")]
        [InlineData("8873")]
        [InlineData(" ")]
        public async Task GetUserByIdShouldReturnNullWhenIdIsInvalid(string objectId)
        {
            //Act
            var actual = await _sut.GetUserById(objectId);

            //Assert
            Assert.Null(actual);
        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                           UpdateUser
         ----------------------------------------------------------------------------------------------------------------------------*/
        [Theory]
        [InlineData(1, null, "Lasse")]
        [InlineData(1, "lasse.larsson@mail.se", null)]
        [InlineData(1, "", "Lars")]
        [InlineData(1, "Lasse", "LarsSomGillarAttSpelaWonderwallPåGitarrVarjeDagLarsSomGillarAttSpelaWonderwallPåGitarrVarjeDagLarsSomGillarAttSpelaWonderwallPåGitarrVarjeDag")]
        [InlineData(1, " ", "LarsSomGillarAttSpelaWonderwallPåGitarrVarjeDag")]
        [InlineData(1, "Email", " ")]
        [InlineData(1, "LarsSomGillarAttSpelaWonderwallPåGitarrVarjeDagLarsSomGillarAttSpelaWonderwalLarsSomGillarAttSpelaWonderwallPåGitarrVarjeDaglPåGitarrVarjeDagLarsSomGillarAttSpelaWonderwallPåGitarrVarjeDagLarsSomGillarAttSpelaWonderwallPåGitarrVarjeDag", " ")]

        public async Task UpdateUserShouldReturnFalseWhenValidationFails(int userId, string? email, string? fName)
        {
            //Arrange
            var user = await _db.Users.FirstOrDefaultAsync(x => x.Id == userId);
            var convertUser = user!.ToDto();
            convertUser!.Email = email!;
            convertUser.Name = fName!;

            //Act
            var updatedUser = await _sut.UpdateUser(convertUser);

            //Assert
            Assert.False(updatedUser);
        }

        [Theory]
        [InlineData("1", "nymail@mail.se", "Hasse")]
        [InlineData("1", "hasse.aro@regionstockholm.se", "Harold")]
        public async Task UpdateUserShouldReturnTrueWhenPropertyIsUpdated(string objectId, string email, string fName)
        {
            //Arrange
            var user = await _db.Users.FirstOrDefaultAsync(x => x.ObjectId == objectId);
            var convertUser = user!.ToDto();

            convertUser!.Email = email;
            convertUser.Name = fName;

            //Act
            var updatedUser = await _sut.UpdateUser(convertUser);

            //Assert
            Assert.True(updatedUser);
        }

        [Theory]
        [InlineData("1", "nymail@mail.se", "Hasse", "nymail@mail.se", "Hasse")]
        [InlineData("1", "hasse.aro@regionstockholm.se", "Harold", "hasse.aro@regionstockholm.se", "Harold")]
        [InlineData("1", "nymail@mail.se", "Harold", "nymail@mail.se", "Harold")]
        public async Task UpdateUserShouldUpdateAndSetAndSaveCorrectNewValuesOnInput(string objectId, string email, string fName, string expectedEmail, string expectedFname)
        {
            //Arrange
            var user = await _db.Users.FirstOrDefaultAsync(x => x.ObjectId == objectId);
            var convertUser = user!.ToDto();
            convertUser!.Email = email;
            convertUser.Name = fName;

            //Act
            var updatedUser = await _sut.UpdateUser(convertUser);

            //Assert
            Assert.True(updatedUser);
            Assert.Equal(expectedFname, convertUser.Name);
            Assert.Equal(expectedEmail, convertUser.Email);
        }

        [Fact]
        public async Task UpdateUserShouldReturnFalseWhenInputUserIsNull()
        {
            //Act
            var updatedUser = await _sut.UpdateUser(null!);

            //Assert
            Assert.False(updatedUser);
        }

        [Fact]
        public async Task UpdateUserShouldReturnFalseWhenUserDoesNotExist()
        {
            //Arrange
            var user = new User { ObjectId = "90", Email = "Mail@Mail.se", Name = "Name" };
            var convertUser = user!.ToDto();

            //Act
            var updatedUser = await _sut.UpdateUser(convertUser!);

            //Assert
            Assert.False(updatedUser);
        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                                 ConvertToUserResponse
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public void ConvertToUserResponseShouldReturnUserResponse()
        {
            //Arrange
            var user = _db.Users.FirstOrDefault();

            //Act
            var userResponse = user!.ToDto();

            //Assert
            Assert.IsType<UserResponse>(userResponse);
            Assert.Equal(userResponse.ObjectId, user!.ObjectId);

        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                                ConvertToUserResponseList
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public void ConvertToUserResponseListShouldReturnListOfUserResponse()
        {
            //Arrange
            var users = _db.Users.ToList();

            //Act
            var userResponse = users!.ToDtoList();

            //Assert

            foreach (var user in userResponse!)
            {
                Assert.IsType<UserResponse>(user);
            }
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                SaveRefreshToken
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public async Task SaveRefreshTokenSHouldUpdateUserRefreshToken()
        {
            //Arrange
            var refreshToken = new RefreshToken
            {
                Token = "abc123",
                Expires = DateTime.UtcNow.AddDays(7)
            };

            //Act
            await _sut.SaveRefreshToken("1", refreshToken);

            //Assert    
            var updatedUser = await _db.Users.FirstAsync(u => u.ObjectId == "1");
            Assert.NotNull(updatedUser.RefreshToken);
            Assert.Equal("abc123", updatedUser.RefreshToken!.Token);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                GetUserByRefreshToken
        ----------------------------------------------------------------------------------------------------------------------------*/

        [Fact]
        public async Task GetUserByRefreshTokenShouldReturnUserWithMatchingToken()
        {
            //Arrange
            var refreshToken = new RefreshToken
            {
                Token = "refresh-999",
                Expires = DateTime.UtcNow.AddDays(5)
            };

            var user = new User
            {
                ObjectId = "user-2",
                Name = "Lurifax",
                Email = "lurifax@manpower.se",
                RefreshToken = refreshToken
            };

            await _db.Users.AddAsync(user);
            await _db.SaveChangesAsync();

            //Act
            var result = await _sut.GetUserByRefreshToken("refresh-999");

            //Assert
            Assert.NotNull(result);
            Assert.Equal("user-2", result!.ObjectId);
        }

        [Fact]
        public async Task GetUserByRefreshTokenShouldReturnNullWhenTokenIsExpired()
        {
            //Arrange
            var user = new User
            {
                ObjectId = "user-expired",
                Name = "Expired User",
                Email = "expired@example.com",
                RefreshToken = new RefreshToken
                {
                    Token = "expired-token-123",
                    Expires = DateTime.UtcNow.AddDays(-1) // expired yesterday
                }
            };

            await _db.Users.AddAsync(user);
            await _db.SaveChangesAsync();

            // Act
            var result = await _sut.GetUserByRefreshToken("expired-token-123");

            // Assert
            Assert.Null(result);
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        public async Task GetUserByRefreshTokenShouldReturnNullWhenTokenIsNullOrEmpty(string? token)
        {
            //Act
            var result = await _sut.GetUserByRefreshToken(token!);

            //Assert    
            Assert.Null(result);
        }
    }
}
