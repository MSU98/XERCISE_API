﻿using Microsoft.EntityFrameworkCore;
using xerciseAPI.Services.WorkoutServices;
using xerciseAPI.Models;
using xerciseAPI.Extensions;
using xerciseAPI.Services.CategoryServices;

namespace XERCISE_Tests.Services.WorkoutServiceTests
{
    public class WorkoutServiceTests : IDisposable
    {
        private readonly TestDb _db;
        private readonly WorkoutService _sut;
        public WorkoutServiceTests()
        {
            _db = new TestDb(
                new DbContextOptionsBuilder<TestDb>()
                .UseInMemoryDatabase(databaseName: "WorkoutTestDb")
                .Options);

            var category1 = new Category() { Id = 1, WorkoutCategory = "Cardio"};
            var category2 = new Category() { Id = 2, WorkoutCategory = "StrengthTraining" };
            _db.Categories.Add(category1);
            _db.Categories.Add(category2);

            var intensity1 = new Intensity() { Id = 1, IntensityGrade = "Light" };
            var intensity2 = new Intensity() { Id = 2, IntensityGrade = "Medium" };
            _db.Intensities.Add(intensity1);
            _db.Intensities.Add(intensity2);

            var user1 = new User() { Id = 1, Email = "hasse.aro@regionstockholm.se", Name = "Hasse", ObjectId ="1"};
            var user2 = new User() { Id = 2, Email = "nils.karlsson@pyssling.se", Name = "Nils", ObjectId = "2" };
            var user3 = new User() { Id = 3, Email = "Lasse.larssonson@syssling.se", Name = "Lasse", ObjectId = "3" };
            var user4 = new User() { Id = 4, Email = "Lisa.larssonson@syssling.se", Name = "Lisa", ObjectId = "4" };
            _db.Users.Add(user1);
            _db.Users.Add(user2);
            _db.Users.Add(user3);
            _db.Users.Add(user4);

            var workout1 = new Workout() { Id = 1, Title = "Workout 1", CategoryId = 1, Activity = "Springtur", IntensityId = 2, Duration = 30, Date = new DateTime(2025, 04, 02, 09, 23, 52), UserId = 1 };
            var workout2 = new Workout() { Id = 2, Title = "Workout 2", CategoryId = 2, Activity = "Simning", IntensityId = 1, Duration = 30, Date = new DateTime(2025, 04, 03, 0, 0, 0), UserId = 2 };
            var workout3 = new Workout() { Id = 3, Title = "Workout 3", CategoryId = 2, Activity = "Klättring", IntensityId = 1, Duration = 30, Date = new DateTime(2025, 04, 03, 0, 0, 0), UserId = 1 };
            var workout4 = new Workout() { Id = 4, Title = "Workout 4", CategoryId = 2, Activity = "Klättring", IntensityId = 1, Duration = 30, Date = new DateTime(2024, 04, 03, 0, 0, 0), UserId = 4 };
            var workout5 = new Workout() { Id = 5, Title = "Workout 5", CategoryId = 2, Activity = "Klättring", IntensityId = 1, Duration = 30, Date = new DateTime(2025, 04, 03, 0, 0, 0), UserId = 4 };
            _db.Workouts.Add(workout1);
            _db.Workouts.Add(workout2);
            _db.Workouts.Add(workout3);
            _db.Workouts.Add(workout4);
            _db.Workouts.Add(workout5);

            _db.SaveChanges();

            _sut = new WorkoutService(_db);
        }

        public void Dispose()
        {
            _db.Database.EnsureDeleted();
            _db.Dispose();
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                        GetUpcomingWorkout
----------------------------------------------------------------------------------------------------------------------------*/

        [Theory]
        [InlineData("2025, 04, 01", "1", 1)]
        [InlineData("2025, 04, 02", "2", 2)]
        public async Task GetUpcomingWorkoutShouldReturnFirstWorkout (string inputDate, string objectId, int expected)
        {

            //Arrange
            var date = DateTime.Parse(inputDate);            

            //Act
            var workouts = await _sut.GetUpcomingWorkout(objectId, date);
            int actual = workouts!.Id;          

            //Assert
            Assert.Equal(expected, actual);

        }

        [Theory]
        [InlineData("0","2025, 04, 02")]
        [InlineData("9999999", "2025, 04, 01")]
        [InlineData("32", "2025, 04, 01")]
        public async Task GetUpcomingWorkoutShouldReturnNullForNonExistingUserId(string objectId, string inputDate)
        {

            //Arrange
            var date = DateTime.Parse(inputDate);

            //Act
            
            var actual = await _sut.GetUpcomingWorkout(objectId, date);

            //Assert
            Assert.Null(actual);
        }

        [Theory]
        [InlineData("1", "2025, 04, 11")]
        [InlineData("2", "2025, 04, 11")]
        [InlineData("3", "2025, 04, 11")]
        public async Task GetUpcomingWorkoutShouldReturnNullForExistingUserIdWithoutUpcomingWorkouts(string objectId, string inputDate)
        {
            //Arrange
            var date = DateTime.Parse(inputDate);

            //Act
            var actual = await _sut.GetUpcomingWorkout(objectId, date);

            //Assert
            Assert.Null(actual);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                GetDurationByCategory
       ----------------------------------------------------------------------------------------------------------------------------*/
        [Theory]
        [InlineData("2024, 04, 03", "4", "StrengthTraining", 30)]
        [InlineData("2025, 04, 03", "1", "StrengthTraining", 30)]
        public async Task GetDurationByCategoryShouldReturnCorrectTotalDurationByCategory(string inputDate, string objectId, string Category, int expected)

        { 
            //Arrange
            var month = DateTime.Parse(inputDate);

            //Act
            var workouts = await _sut.GetDurationByCategory(objectId, month);
            var actual = workouts!.FirstOrDefault(c => c.Category == Category);

            //Assert
            Assert.Equal(expected, actual.Duration);
        }

        [Theory]
        [InlineData("2025, 04, 01", "6")]
        [InlineData("2024, 04, 03", "9999999")]
        [InlineData("2024, 04, 03", "32")]
        public async Task GetDurationByCategoryReturnNullForNonExistingUserId(string inputDate, string objectId)
        {
            //Arrange
            var month = DateTime.Parse(inputDate);

            //Act
            var actual = await _sut.GetDurationByCategory(objectId,month);

            //Assert
            Assert.Null(actual);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                    GetWorkoutCountByCategory
           ----------------------------------------------------------------------------------------------------------------------------*/
        [Theory]
        [InlineData("2024, 04, 03","4", "StrengthTraining", 1)]
        [InlineData("2025, 04, 03","1", "StrengthTraining", 1)]
        public async Task GetWorkoutCountByCategoryShouldReturnCorrectAmountAsync(string inputDate,string objectId, string workoutCategory, int expected)
        {
            //Arrange
            var month = DateTime.Parse(inputDate);

            //Act
            var workouts = await _sut.GetWorkoutCountByCategory(objectId, month);
            var actual = workouts!.FirstOrDefault(c => c.WorkoutCategory == workoutCategory);

            //Assert
            Assert.Equal(expected, actual.Count);

        }

        [Theory]
        [InlineData("2025, 04, 03", "999")]
        [InlineData("2024, 01, 01", "nonexistent")]
        public async Task GetWorkoutCountByCategoryShouldReturnNullForNonExistingUserId(string inputDate, string objectId)
        {
            // Arrange
            var month = DateTime.Parse(inputDate);

            // Act
            var result = await _sut.GetWorkoutCountByCategory(objectId, month);

            // Assert
            Assert.Null(result);
        }

        [Theory]
        [InlineData("2025, 01, 01", "3")] 
        [InlineData("2025, 12, 01", "1")] 
        public async Task GetWorkoutCountByCategoryShouldReturnEmptyListForExistingUserWithoutWorkouts(string inputDate, string objectId)
        {
            // Arrange
            var month = DateTime.Parse(inputDate);

            // Act
            var result = await _sut.GetWorkoutCountByCategory(objectId, month);

            // Assert
            Assert.NotNull(result);
            Assert.Empty(result);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  GetAllWorkouts
        ----------------------------------------------------------------------------------------------------------------------------*/

        [Theory]
        [InlineData("1", 2)]
        [InlineData("2", 1)]
        public async Task GetAllWorkoutShouldReturnAllWorkoutsForAUser(string objectId, int expected)
        {
            //Act
            var workouts = await _sut.GetAllWorkouts(objectId);
            var actual = workouts?.Count;

            //Assert
            Assert.Equal(expected, actual);
        }

        [Theory]
        [InlineData("6")]
        [InlineData("9999999")]
        [InlineData("32")]
        public async Task GetAllWorkoutsShouldReturnNullForNonExistingUserId(string objectId)
        {
            //Act
            var actual = await _sut.GetAllWorkouts(objectId);

            //Assert
            Assert.Null(actual);
        }

        [Fact]
        public async Task GetAllWorkoutsShouldReturnNullForExistingUserIdWithoutWorkouts()
        {
            //Arrange
            string objectId = "3";

            //Act
            var actual = await _sut.GetAllWorkouts(objectId);

            //Assert
            Assert.Null(actual);
        }

        [Theory]
        [InlineData("1", "Category", "Cardio")]
        [InlineData("1", "Intensity", "Medium")]
        public async Task GetAllWorkoutsShouldReturnCorrectValueForProperty(string objectId, string propertyToCheck, string expected)
        {
            //Arrange
            string actual;

            //Act
            var workout = await _sut.GetAllWorkouts(objectId);

            if (propertyToCheck == "Category")
            {
                actual = workout![0].Category!;
            }
            else
            {
                actual = workout![0].Intensity!;
            }

            //Assert
            Assert.Equal(expected, actual);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  GetWorkoutsByDate
         ----------------------------------------------------------------------------------------------------------------------------*/

        [Theory]
        [InlineData("2025, 04, 03", "1", 1)]
        [InlineData("2025, 04, 03", "2", 1)]
        [InlineData("2025-04-02T15:30:00", "1", 1)]
        public async Task GetWorkoutsByDateShouldReturnWorkoutsWhenDateMatchesRegardlessOfTime(string inputDate, string objectId, int expected)
        {
            //Arrange
            var date = DateTime.Parse(inputDate);

            //Act
            var workouts = await _sut.GetWorkoutsByDate(objectId, date);
            int actual = workouts!.Count;

            //Assert
            Assert.Equal(expected, actual);
        }

        [Fact]
        public async Task GetWorkoutsByDateShouldReturnNullForExistingUserIdWithoutWorkouts()
        {
            //Arrange
            DateTime date = new DateTime(2025, 02, 03);
            string objectId = "3";

            //Act
            var actual = await _sut.GetWorkoutsByDate(objectId, date);

            //Assert
            Assert.Null(actual);
        }

        [Theory]
        [InlineData("2025, 03, 03", "1")] //Existing User, Non Existing Workout
        [InlineData("2025, 05, 03", "6")] //Non Existing User, Non Existing Workout
        [InlineData("2025-04-02T15:30:00", "4")] //Non Existing User, Existing Workout
        public async Task GetWorkoutsByDateShouldReturnNullWhenDateOrUserIdDoesNotExist(string inputDate, string objectId)
        {
            //Arrange
            var date = DateTime.Parse(inputDate);

            //Act
            var actual = await _sut.GetWorkoutsByDate(objectId, date);

            //Assert
            Assert.Null(actual);
        }

        [Theory]
        [InlineData("2025, 04, 03", "2", "Category", "StrengthTraining")]
        [InlineData("2025, 04, 03", "2", "Intensity", "Light")]
        public async Task GetWorkoutsByDateShouldReturnCorrectValueForProperty(string inputDate , string objectId, string propertyToCheck, string expected)
        {
            //Arrange
            var date = DateTime.Parse(inputDate);
            string actual;

            //Act
            var workouts = await _sut.GetWorkoutsByDate(objectId, date);
            if (propertyToCheck == "Category")
            {
                actual = workouts![0].Category!;
            }
            else
            {
                actual = workouts![0].Intensity!;
            }

            //Assert
            Assert.Equal(expected, actual);
        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  GetWorkoutsById
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Theory]
        [InlineData(1, "1", "Workout 1")]
        [InlineData(3, "1", "Workout 3")]
        [InlineData(2, "2", "Workout 2")]
        public async Task GetWorkoutByIdShouldReturnCorrectWorkoutByIdThatMatchesUser(int workoutId, string objectId, string expected )
        {
            //Act
            var actual = await _sut.GetWorkoutById(workoutId, objectId);

            //Assert
            Assert.Equal(expected, actual!.Title);
        }


        [Theory]
        [InlineData(-45, "1")]
        [InlineData(8873, "1")]
        public async Task GetWorkoutByIdShouldReturnNullWhenWorkoutIdIsInvalid(int workoutId, string objectId)
        {
            //Act
            var actual = await _sut.GetWorkoutById(workoutId, objectId);

            //Assert
            Assert.Null(actual);
        }


        [Fact]
        public async Task GetWorkoutByIdShouldReturnNullWhenWorkoutIdBelongsToAnotherUser()
        {
            //Arrange
            var workoutId = 2;
            var objectId = "1";

            //Act
            var actual = await _sut.GetWorkoutById(workoutId, objectId);

            //Assert
            Assert.Null(actual);
        }
        [Theory]
        [InlineData(1,"1", "Category", "Cardio")]
        [InlineData(1,"1", "Intensity", "Medium")]
        public async Task GetWorkoutByIdShouldReturnCorrectValueForProperty(int workoutId, string objectId, string propertyToCheck, string expected)
        {
            //Arrange
            string actual;

            //Act
            var workout = await _sut.GetWorkoutById(workoutId, objectId);

            if (propertyToCheck == "Category")
            {
                actual = workout!.Category!;
            }
            else 
            { 
                actual = workout!.Intensity!;
            }

            //Assert
            Assert.Equal(expected, actual);
        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                                    CreateWorkout
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public async Task CreateWorkoutShouldCreateANewWorkoutIfInputValidData()
        {
            //Arrange
            var workout = new CreateWorkoutDto()
            {
                Title = "Kvällsjogg",
                CategoryId = 2,
                Activity = "Löpning",
                IntensityId = 2,
                Duration = 120,
                Date = DateTime.Now,
                ObjectId = "3"
            };

            //Act
            var createdWorkout = await _sut.CreateWorkout(workout);
            var expected = 1;
            var workouts = await _sut.GetAllWorkouts("3");
            var actual = workouts!.Count;

            //Assert
            Assert.Equal(expected, actual);
            Assert.True(createdWorkout);
        }

        [Theory]
        [InlineData("kvällsrunda där jag tog en jättefin och trevlig promenad runt ån och det var trevlig att träffa hasses hund och sånt dära.", 1, "inlines", 1, 1,"2025, 03, 02", "1" )]
        [InlineData("haha", -1, "inlines", 1, 1, "2025, 03, 02", "1")]
        [InlineData("hihi", 1, null, 1, 1, "2025, 03, 02", "1")]
        [InlineData("tihi", 1, "inlines", -1, 1, "2025, 03, 02", "1")]
        [InlineData("taha", 1, "inlines", 1, -1, "2025, 03, 02", "1")]
        [InlineData("tehe", 1, "inlines", 1, 1, "2025, 03, 02", "0")]
        public async Task CreateWorkoutShouldReturnNullIfInputDataIsInvalid(string title,
            int categoryId, string? activity, int intensityId,
            int length, string inputDate, string objectId)
        {
            //Arrange
            DateTime date = DateTime.Parse(inputDate);
            var workout = new CreateWorkoutDto()
            {
                Title = title,
                CategoryId = categoryId,
                Activity = activity,
                IntensityId = intensityId,
                Duration = length,
                Date = date,
                ObjectId = objectId
            };

            //Act
            var actual = await _sut.CreateWorkout(workout);

            //Assert
            Assert.False(actual);
        }

        [Fact]
        public async Task CreateWorkoutShouldReturnNullWhenMissingFields()
        {
            //All fields in validator have NotEmpty() on them,
            //Therefore testing that one is absent should render the same result regardless of which field is empty.

            var workout = new CreateWorkoutDto()
            {
                Title = "Kvällsjogg",
                CategoryId = 2,
                //Activity = "Löpning",
                IntensityId = 2,
                Duration = 120,
                Date = DateTime.Now,
                ObjectId = "3"
            };

            //Act
            var actual = await _sut.CreateWorkout(workout);

            //Assert
            Assert.False(actual);
        }

        [Fact]
        public async Task CreateWorkoutShouldReturnNullWhenInputIsNull()
        {
            //Act
            var actual = await _sut.CreateWorkout(null!);

            //Assert
            Assert.False(actual);
        }

        /*----------------------------------------------------------------------------------------------------------------------------
                                                                  DeleteWorkout
         ----------------------------------------------------------------------------------------------------------------------------*/

        [Theory]
        [InlineData(45)]
        [InlineData(-32)]
        [InlineData(99999)]
        [InlineData(0)]
        public async Task DeleteWorkoutShouldReturnFalseWhenWorkoutIdDoesNotExist(int workoutId)
        {
            //Act
            var actual = await _sut.DeleteWorkout(workoutId);

            //Assert
            Assert.False(actual);
        }

        [Fact]
        public async Task DeleteWorkoutShouldReturnTrueOnDelete()
        {
            //Arrange
            int workoutId = 1;

            //Act
            var actual = await _sut.DeleteWorkout(workoutId);

            //Assert

            Assert.True(actual);
        }
        [Fact]
        public async Task DeleteWorkoutShouldDeleteWorkout()
        {
            //Arrange
            int workoutId = 1;
            string objectId = "1";
            int expected = 1;

            //Act
            await _sut.DeleteWorkout(workoutId);

            List<WorkoutResponse>? workouts = await _sut.GetAllWorkouts(objectId);
            int actual = workouts!.Count;

            //Assert
            Assert.Equal(expected, actual);

        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                                 GetWorkoutDataByMonth
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Theory]
        [InlineData("2025, 04, 03", "4")]
        [InlineData("2025-04-03T15:30:00", "4")]
        public async Task GetWorkoutDataByMonthShouldReturnWorkoutsRegardlessOfTimeAndYear(string inputDate, string objectId)
        {
            //Arrange
            DateTime month= DateTime.Parse(inputDate);
            int expectedYear = 2025;
            int expectedMonth = 4;

            //Act
            List<WorkoutData>? workouts = await _sut.GetWorkoutDataByMonth(objectId, month);
            int actualYear = workouts![0].Date.Year; 
            int actualMonth = workouts![0].Date.Month;

            //Assert
            Assert.Equal(expectedYear, actualYear);
            Assert.Equal(expectedMonth, actualMonth);
        }
        [Fact]
        public async Task GetWorkoutDataByMonthShouldReturnNullWhenUserHasNoWorkouts()
        {
            //Arrange
            string objectId = "3";
            DateTime month = new DateTime(2025, 03, 03);

            //Act
            List<WorkoutData>? workouts = await _sut.GetWorkoutDataByMonth(objectId, month);

            //Assert
            Assert.Null(workouts);
        }
        [Fact]
        public async Task GetWorkoutDataByMonthShouldReturnCorrectNumberOfWorkouts()
        {
            //Arrange
            string objectId = "1";
            DateTime month = new DateTime(2025, 04, 03);
            int expected = 2;

            //Act
            List<WorkoutData>? workouts = await _sut.GetWorkoutDataByMonth(objectId, month);
            int actual = workouts!.Count;

            //Assert
            Assert.Equal(expected, actual);
        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                                ConvertToWorkoutResponse
        ----------------------------------------------------------------------------------------------------------------------------*/

        [Fact]
        public void ConvertToWorkoutResponseShouldReturnAWorkoutResponse()
        {
            //Arrange
            var workout = _db.Workouts.FirstOrDefault();

            //Act
            var workoutResponse = workout!.ToDto();

            //Assert
            Assert.IsType<WorkoutResponse>(workoutResponse);
            Assert.Equal(workoutResponse.Id, workout!.Id);

        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                               ConvertToWorkoutResponseList
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public void ConvertToWorkoutResponseListShouldReturnAListOfWorkoutResponses()
        {
            //Arrange
            var workouts = _db.Workouts.ToList();

            //Act
            var workoutResponses = workouts.ToDtoList();

            //Assert

            foreach(var workout in workoutResponses!)
            {
                Assert.IsType<WorkoutResponse>(workout);
            }
        }

        [Fact]
        public void ConvertToWorkoutResponseListShouldReturnWithCorrectMapping()
        {
            //Arrange
            var workouts = _db.Workouts.ToList();

            //Act
            var workoutResponses = workouts.ToDtoList();

            //Assert
            for(int i = 0; i < workouts.Count; i++)
            {
                Assert.Equal(workouts[i].Id, workoutResponses![i].Id);
                Assert.Equal(workouts[i].Title, workoutResponses![i].Title);
                Assert.Equal(workouts[i].Category.WorkoutCategory, workoutResponses![i].Category);
                Assert.Equal(workouts[i].Activity, workoutResponses![i].Activity);
                Assert.Equal(workouts[i].Intensity.IntensityGrade, workoutResponses![i].Intensity);
                Assert.Equal(workouts[i].Duration, workoutResponses![i].Duration);
                Assert.Equal(workouts[i].Date, workoutResponses![i].Date);
            }
        }
        /*----------------------------------------------------------------------------------------------------------------------------
                                                                 ConvertToWorkoutData
        ----------------------------------------------------------------------------------------------------------------------------*/
        [Fact]
        public void ConvertToWorkoutDataShouldReturnWorkoutData()
        {
            //Arrange
            var workouts = _db.Workouts.ToList();

            //Act
            var workoutData = _sut.ConvertToWorkoutData(workouts);

            //Assert
            foreach (var workout in workoutData!)
            {
                Assert.IsType<WorkoutData>(workout);
            }
        }
        [Fact]
        public void ConvertToWorkoutDataShouldReturnCorrectValues()
        {
            //Arrange
            var workouts = _db.Workouts.ToList();
            string expectedCategory = "Cardio";
            int expectedDuration = 30;
            DateTime expectedDate = new DateTime(2025, 04, 02);

            //Act
            var workoutData = _sut.ConvertToWorkoutData(workouts);

            //Assert
            Assert.Equal(expectedCategory, workoutData![0].Category);
            Assert.Equal(expectedDuration, workoutData[0].Duration);
            Assert.Equal(expectedDate, workoutData[0].Date.Date);
        }
        [Fact]
        public void ConvertToWorkoutDataShouldReturnNullWhenInputIsNull()
        {
            //Act

            var workoutResponses = _sut.ConvertToWorkoutData(null!);

            //Assert
            Assert.Null(workoutResponses);
        }
    }
}

