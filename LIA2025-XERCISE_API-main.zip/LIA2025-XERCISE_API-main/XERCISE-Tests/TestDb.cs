﻿using Microsoft.EntityFrameworkCore;
using xerciseAPI.Data;
using xerciseAPI.Models;

namespace XERCISE_Tests
{
    public class TestDb : DbContext, IDatabase
    {
        public DbSet<Category> Categories { get; set; }

        public DbSet<Intensity> Intensities { get; set; }

        public DbSet<User> Users { get; set; }

        public DbSet<Workout> Workouts { get; set; }
        public DbSet<StepEntry> StepEntries { get; set; }

        public DbSet<StepGoal> StepGoals { get; set; }


        public TestDb(DbContextOptions<TestDb> options) : base(options) { }

        public async Task<int> SaveChangesAsync()
        {
            return await base.SaveChangesAsync();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // This is the key part!
            modelBuilder.Entity<User>(entity =>
            {
                entity.OwnsOne(e => e.RefreshToken, rt =>
                {
                    rt.Property(r => r.Token).HasMaxLength(500);
                    rt.Property(r => r.Expires);
                });
            });
        }

    }
}