﻿namespace xerciseAPI.Data
{
    public interface IDatabase
    {
        public  DbSet<Category> Categories { get; set; }
        public  DbSet<Intensity> Intensities { get; set; }
        public  DbSet<User> Users { get; set; }
        public  DbSet<Workout> Workouts { get; set; }
        public DbSet<StepEntry> StepEntries { get; set; }
        public DbSet<StepGoal> StepGoals { get; set; }
        Task<int> SaveChangesAsync();
    }
}
