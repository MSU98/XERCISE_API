﻿namespace xerciseAPI.Data;

public partial class XerciseDbContext : DbContext, IDatabase
{
    private readonly IConfiguration _configuration;
    public XerciseDbContext(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public XerciseDbContext(DbContextOptions<XerciseDbContext> options, IConfiguration configuration)
        : base(options)
    {
        _configuration = configuration;
    }
    public async Task<int> SaveChangesAsync()
    {
        return await base.SaveChangesAsync();
    }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<Intensity> Intensities { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<Workout> Workouts { get; set; }
    public virtual DbSet<StepEntry> StepEntries { get; set; }
    public virtual DbSet<StepGoal> StepGoals { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer(_configuration.GetConnectionString("DefaultConnection"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Category__3214EC077CEB3EAC");
            entity.HasIndex(e => e.Id).IsUnique();

            entity.ToTable("Category");
            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.WorkoutCategory)
                .HasMaxLength(50);
            entity.HasData(
                new Category
                {
                    Id = 1,
                    WorkoutCategory = "Cardio"
                },
                new Category
                {
                    Id = 2,
                    WorkoutCategory = "Strength"
                },
                new Category
                {
                    Id = 3,
                    WorkoutCategory = "Everyday"
                },
                new Category
                {
                    Id = 4,
                    WorkoutCategory = "Group"
                }
                );
        });

        modelBuilder.Entity<Intensity>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Intensit__3214EC07684AC7FF");
            entity.HasIndex(e => e.Id).IsUnique();

            entity.ToTable("Intensity");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.IntensityGrade)
                .HasMaxLength(50);
            entity.HasData(
                new Intensity
                {
                    Id = 1,
                    IntensityGrade = "Low"
                },
                new Intensity
                {
                    Id = 2,
                    IntensityGrade = "Moderate"
                },
                new Intensity
                {
                    Id = 3,
                    IntensityGrade = "High"
                }
                );
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__User__3214EC07263786A6");
            entity.HasIndex(e => e.Id).IsUnique();

            entity.ToTable("User");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.Email)
                .HasMaxLength(100);
            entity.Property(e => e.Name)
                .HasMaxLength(50);

            entity.OwnsOne(e => e.RefreshToken);
        });

        modelBuilder.Entity<Workout>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Workout__3214EC071FDBA014");
            entity.HasIndex(e => e.Id).IsUnique();

            entity.ToTable("Workout");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.Activity)
                .HasMaxLength(250);
            entity.Property(e => e.CategoryId).HasColumnName("CategoryID");
            entity.Property(e => e.Date);
            entity.Property(e => e.IntensityId).HasColumnName("IntensityID");
            entity.Property(e => e.Title)
                .HasMaxLength(50);
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.Category).WithMany(p => p.Workouts)
                .HasForeignKey(d => d.CategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Workout_Category");

            entity.HasOne(d => d.Intensity).WithMany(p => p.Workouts)
                .HasForeignKey(d => d.IntensityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Workout_Intensity");

            entity.HasOne(d => d.User).WithMany(p => p.Workouts)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Workout_User");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
