﻿namespace xerciseAPI.Endpoints
{
    public static class AuthEndpoints
    {
        public static void RegisterAuthEndpoints(this IEndpointRouteBuilder app)
        {
            app.MapPost("/auth/login", async (IUserService _userService,
                IAuthService _authService,
                UserResponse user,
                ILogger<Program> logger) =>
            {
                var existingUser = await _userService.GetUserById(user.ObjectId!);

                var token = _authService.CreateToken(user);
                var refreshToken = _authService.GenerateRefreshToken();


                if (existingUser == null)
                {
                    var creationSuccessful = await _userService.CreateUser(user);

                    await _userService.SaveRefreshToken(user.ObjectId!, refreshToken);

                    if (!creationSuccessful)
                    {
                        logger.LogError("User {user.ObjectId} could not be created", user.ObjectId);
                        return Results.BadRequest("Failed to create user");
                    }

                    logger.LogInformation("User {user.ObjectId} was Successfully created", user.ObjectId);
                    return Results.Created("User created", token);

                }

                await _userService.SaveRefreshToken(user.ObjectId!, refreshToken);
                logger.LogInformation("User {user.ObjectId} exists, logged in", user.ObjectId);
                return Results.Ok(new { token, refreshToken = refreshToken.Token });
            }).WithTags("Auth")
            .AllowAnonymous();

        app.MapPost("auth/refresh", async (string refreshToken,
            IAuthService _authService,
            IUserService _userService,
            ILogger<Program> logger) => 
            {
                var user = await _userService.GetUserByRefreshToken(refreshToken);

                if(user == null || user.RefreshToken!.IsExpired)
                {
                    logger.LogError("User {user.ObjectId} was null or refreshtoken is expired?:{user.RefreshToken.IsExpired}", user!.ObjectId, user.RefreshToken!.IsExpired);
                    return Results.Unauthorized();
                }

                var newAccessToken = _authService.CreateToken(user);
                var newRefreshToken = _authService.GenerateRefreshToken();
                await _userService.SaveRefreshToken(user.ObjectId!, newRefreshToken);

                logger.LogInformation("user {user.ObjectId} got a new refreshtoken {newRefreshToken.Token}", user.ObjectId, newRefreshToken.Token);
                return Results.Ok(new
                {
                    token = newAccessToken,
                    refreshToken = newRefreshToken.Token
                });
        
            }).WithTags("Auth").AllowAnonymous();
        }
    }
}
