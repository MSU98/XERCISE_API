﻿using xerciseAPI.Extensions;

namespace xerciseAPI.Endpoints
{
    public static class CategoryEndpoints
    {
        public static void RegisterCategoryEndpoints(this IEndpointRouteBuilder app)
        {

            app.MapGet("/categories", (ICategoryService _categoryService,
                ILogger<Program> logger) =>
            {
                var categories = _categoryService.GetAllCategories();

                if (categories.IsNullOrEmpty())
                {
                    logger.LogError("No Categories could be found");
                    return Results.NotFound("No Categories could be found");
                }

                logger.LogInformation("Returned list of Categories");
                return Results.Ok(categories);
            }).WithTags("Category");


            app.MapGet("/categories/{categoryId}", (ICategoryService _categoryService,
                int categoryId,
                ILogger<Program> logger) =>
            {
                var category = _categoryService.GetCategoryById(categoryId);

                if (category == null)
                {
                    logger.LogError("Category with id {categoryId} could not be found", categoryId);
                    return Results.NotFound("Category could not be found");
                }

                logger.LogInformation("Category with id:{categoryId} returned", categoryId);
                return Results.Ok(category);
            }).WithTags("Category");


            app.MapPost("/categories", async (ICategoryService _categoryService,
                string workoutCategory,
                ILogger<Program> logger) =>
            {
                var creationSuccess = await _categoryService.CreateCategory(workoutCategory);

                if (creationSuccess) return Results.Created("Category Successfully created", creationSuccess);


                logger.LogError("Could not create Category: {workoutCategory}", workoutCategory);
                return Results.BadRequest("Category could not be created");
            }).WithTags("Category");


            app.MapDelete("/categories/{categoryId}", async (ICategoryService _categoryService,
                int categoryId,
                ILogger<Program> logger) =>

            {
                var deletionSuccess = await _categoryService.DeleteCategory(categoryId);


                if (deletionSuccess)
                {
                    logger.LogInformation("Deleting category: {categoryId}", categoryId);
                    return Results.Ok("Category Successfully deleted");
                }


                logger.LogError("Category with id {categoryId} could not be found", categoryId);
                return Results.NotFound("Category could not be deleted");
            }).WithTags("Category");


            app.MapPatch("/categories/{categoryId}", async (ICategoryService _categoryService,
                int categoryId,
                string workoutCategory,
                ILogger<Program> logger) =>
            {
                var updateSuccess = await _categoryService.UpdateCategory(categoryId, workoutCategory);

                if (updateSuccess)
                {
                    logger.LogInformation("{workoutCategory} was successfully updated", workoutCategory);
                    return Results.NoContent();
                }

                logger.LogError("Category with id {categoryId} could not be updated", workoutCategory);
                return Results.NotFound("Category could not be updated");
            }).WithTags("Category");
        }
    }
}
