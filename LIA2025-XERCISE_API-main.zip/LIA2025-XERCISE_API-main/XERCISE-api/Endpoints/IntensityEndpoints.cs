﻿using xerciseAPI.Extensions;

namespace xerciseAPI.Endpoints
{
    public static class IntensityEndpoints
    {
        public static void RegisterIntensityEndpoints(this IEndpointRouteBuilder app)
        {

            app.MapGet("/intensities", (IIntensityService _intensityService,
                ILogger<Program> logger) =>
            {
                var intensities = _intensityService.GetAllIntensities();

                if (intensities.IsNullOrEmpty())
                {
                    logger.LogError("No Intensities found");
                    return Results.NotFound("No Intensities could be found");
                }

                logger.LogInformation("Returned all Intensities");
                return Results.Ok(intensities);
            }).WithTags("Intensity");


            app.MapGet("/intensities/{intensityId}", (IIntensityService _intensityService,
                int intensityId,
                ILogger<Program> logger) =>
            {
                var intensity = _intensityService.GetIntensityById(intensityId);

                if (intensity == null)
                {
                    logger.LogError("{intensityId} was not found", intensityId);
                    return Results.NotFound("Intensity could not be found");
                }

                logger.LogInformation("Intensity {intensityId} returned", intensityId);
                return Results.Ok(intensity);
            }).WithTags("Intensity");


            app.MapPost("/intensities", async (IIntensityService _intensityService,
                string intensityGrade,
                ILogger<Program> logger) =>
            {
                var creationSuccess = await _intensityService.CreateIntensity(intensityGrade);

                if (creationSuccess)
                {
                    logger.LogInformation("{intensityGrade} was successfully created", intensityGrade);
                    return Results.Created("Intensity Successfully created", creationSuccess);
                }

                logger.LogError("Could not create intensity {intensityGrade}", intensityGrade);
                return Results.BadRequest("Intensity could not be created");
            }).WithTags("Intensity");


            app.MapDelete("/intensities/{intensityId}", async (IIntensityService _intensityService,
                int intensityId,
                ILogger<Program> logger) =>
            {
                var deletionSuccess = await _intensityService.DeleteIntensity(intensityId);

                if (deletionSuccess)
                {
                    logger.LogInformation("Intensity with id {intensityId} was successfully deleted", intensityId);
                    return Results.Ok("Intensity Successfully deleted");
                }

                logger.LogError("Could not delete intensity with id {intensityId}", intensityId);
                return Results.NotFound("Intensity could not be deleted");
            }).WithTags("Intensity");


            app.MapPatch("/intensities/{intensityId}", async (IIntensityService _intensityService,
                int intensityId,
                string intensityGrade,
                ILogger<Program> logger) =>
            {
                var updateSuccess = await _intensityService.UpdateIntensity(intensityId, intensityGrade);

                if (updateSuccess)
                {
                    logger.LogInformation("Intensity {intensityGrade} was successfully updated", intensityGrade);
                    return Results.NoContent();
                }

                logger.LogError("Intensity with Id {intensityId} could not be updated", intensityGrade);
                return Results.NotFound("Intensity could not be updated");
            }).WithTags("Intensity");
        }
    }
}
