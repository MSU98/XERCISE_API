﻿using xerciseAPI.Services.StepEntryServices;

namespace xerciseAPI.Endpoints
{
    public static class StepEntryEndpoints
    {
        public static void RegisterStepEntryEndpoints(this IEndpointRouteBuilder app)
        {
            app.MapGet("/steps/{userObjectId}/byDate", async (IStepEntryService stepEntryService,
                string userObjectId,
                DateTime date,
                ILogger<Program> logger) =>
         {
             var steps = await stepEntryService.GetSteps(userObjectId, date);

             if (steps == null) 
             {
                 logger.LogError("Steps for user {userObjectId} on {date} could not be found", userObjectId, date);
                 return Results.NoContent();
             }

             logger.LogInformation("Returned steps for user {userObjectId}", userObjectId);
             return Results.Ok(steps);

         }).WithTags("StepEntry");

            app.MapPut("/steps/{userObjectId}", async (IStepEntryService stepEntryService,
                string userObjectId,
                int addSteps,
                DateTime date,
                ILogger<Program> logger) =>
            {
                var steps = await stepEntryService.SaveStepsOnDate(userObjectId, addSteps, date);

                if (steps == false)
                {
                    logger.LogError("Failed to save steps for user {userObjectId} on date {date}", userObjectId, date);
                    return Results.BadRequest("Could not save steps");
                }

                logger.LogInformation("Steps for user {userObjectId} on date {date} is saved/updated", userObjectId, date);
                return Results.Created("Steps successfully saved/updated", steps);
            }).WithTags("StepEntry");

            app.MapDelete("/steps/{userObjectId}/byDate", async (IStepEntryService _stepEntryService,
                string userObjectId,
                DateTime date,
                ILogger<Program> logger) =>
            {
                var deleted = await _stepEntryService.DeleteStepsOnDate(userObjectId, date);

                if (deleted)
                {
                    logger.LogInformation("Steps delete for user {userObjectId} on date {date}", userObjectId, date);
                    return Results.Ok("Steps deleted");
                }
                logger.LogError("Steps for user {userObjectId} not found or could not be deleted", userObjectId);
                return Results.NotFound("Steps could not be deleted");
            }).WithTags("StepEntry");
        }
    }
}
