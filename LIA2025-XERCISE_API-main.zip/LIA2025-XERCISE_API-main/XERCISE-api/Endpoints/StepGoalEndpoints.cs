﻿using Microsoft.AspNetCore.Http.HttpResults;
using xerciseAPI.Services.StepEntryServices;
using xerciseAPI.Services.StepGoalServices;

namespace xerciseAPI.Endpoints
{
    public static class StepGoalEndpoints
    {
        public static void RegisterStepGoalEndpoints(this IEndpointRouteBuilder app)
        {
            app.MapGet("/stepGoals/{userObjectId}", async (IStepGoalService _stepGoalService,
                string userObjectId,
                ILogger<Program> logger) =>
            {
                var goal = await _stepGoalService.GetStepGoal(userObjectId);

                if (goal == null)
                {
                    logger.LogError("Step goal for user {userObjectId} not found", userObjectId);
                    return Results.NoContent();
                }

                logger.LogInformation("Returned goal for user {userObjectId}", userObjectId);
                return Results.Ok(goal);
            }).WithTags("StepGoal");

            app.MapPut("/stepGoals/{userObjectId}", async (IStepGoalService _stepGoalService,
                string userObjectId,
                int stepGoal,
            ILogger<Program> logger) =>
            {
                var goal = await _stepGoalService.SaveStepGoal(userObjectId, stepGoal);

                if (goal == false)
                {
                    logger.LogError("Failed to save step goal for user {userObjectId}", userObjectId);
                    return Results.BadRequest("Could not save step goal");
                }
                logger.LogInformation("Step goal for user {userObjectId} is saved/updated", userObjectId);
                return Results.Created("Step goal successfully saved/updated", goal);
               
            }).WithTags("StepGoal");

            app.MapDelete("/stepGoals/{userObjectId}", async (IStepGoalService _stepGoalService,
                string userObjectId,
                ILogger<Program> logger) =>
            {
                var deleted = await _stepGoalService.DeleteStepGoal(userObjectId);

                if (deleted)
                {
                    logger.LogInformation("Step goal for user {userObjectId} deleted", userObjectId);
                    return Results.Ok("Step goal deleted");
                }

                logger.LogError("Step goal for user {userObjectId} not found or could not be deleted", userObjectId);
                return Results.NotFound("Step goal could not be deleted");
            }).WithTags("StepGoal");

            app.MapGet("/stepGoals/progress/{userObjectId}/byDate", async (
                IStepGoalService stepGoalService,
                string userObjectId,
                DateTime date,
                ILogger<Program> logger) =>
            {
                var progress = await stepGoalService.GetStepProgressByDate(userObjectId, date);
                if (progress == null)
                {
                    logger.LogError("User {userObjectId} not found", userObjectId);
                    return Results.NotFound("User not found");
                }

                logger.LogInformation("Returning step progress for user {userObjectId}", userObjectId);
                return Results.Ok(progress);
            }).WithTags("StepGoal");
        }
    }
}
