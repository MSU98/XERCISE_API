﻿namespace xerciseAPI.Endpoints
{
    public static class UserEndpoints
    {
        public static void RegisterUserEndpoints(this IEndpointRouteBuilder app)
        {
            app.MapGet("/users", async (IUserService _userService, ILogger<Program> logger) =>
            {
                var users = await _userService.GetAllUsers();

                if (users == null)
                {
                    logger.LogError("No Users found");
                    return Results.NotFound("Users could not be found");
                }

                logger.LogInformation("Returned all Users");
                return Results.Ok(users);
            }).WithTags("Users");

            app.MapDelete("/users/{userId}", async (IUserService _userService, int userId, ILogger<Program> logger) =>
            {
                if (userId <= 0) return Results.NotFound("User could not be found");

                var deletionSuccessful = await _userService.DeleteUser(userId);

                if (deletionSuccessful)
                {
                    logger.LogInformation("User {userId} deleted", userId);
                    return Results.Ok("User Successfully deleted");
                }

                logger.LogError("User with id {userId} could not be deleted", userId);
                return Results.BadRequest("User could not be deleted");
            }).WithTags("Users");

            app.MapGet("/users/{userObjectId}", async (IUserService _userService, string userObjectId, ILogger<Program> logger) =>
            {
                if (userObjectId == null)
                {
                    logger.LogError("User with id {userObjectId} could not be found", userObjectId);
                    return Results.NotFound("User could not be found");
                }

                var user = await _userService.GetUserById(userObjectId);

                if (user == null)
                {
                    logger.LogError("{userObjectId} is not a User", userObjectId);
                    return Results.NotFound("User could not be found");
                }

                logger.LogInformation("Found and returned User {user.ObjectId}", user.ObjectId);
                return Results.Ok(user);
            }).WithTags("Users");

            app.MapPatch("/users", async (IUserService _userService, UserResponse user, ILogger<Program> logger) =>
            {
                if (user == null)
                {
                    logger.LogError("Input to update User was null");
                    return Results.NotFound("User could not be found");
                }

                var updateSuccessful = await _userService.UpdateUser(user);

                if (updateSuccessful)
                {
                    logger.LogInformation("Successfully updated User {user.ObjectId}", user.ObjectId);
                    return Results.NoContent();
                }

                logger.LogError("Could not update User {user.ObjectId}", user.ObjectId);
                return Results.NotFound("User could not be updated.");

            }).WithTags("Users");
        }
    }
}
