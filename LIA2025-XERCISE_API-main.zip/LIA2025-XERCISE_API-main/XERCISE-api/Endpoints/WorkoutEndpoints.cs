﻿using Microsoft.Extensions.Logging;
using xerciseAPI.Models;

namespace xerciseAPI.Endpoints
{
    public static class WorkoutEndpoints
    {
        public static void RegisterWorkoutEndpoints(this IEndpointRouteBuilder app)
        {
            app.MapGet("/workouts/{userObjectId}", async (IWorkoutService _workoutService,
                string userObjectId,
                ILogger<Program> logger) =>
            {
                if (userObjectId == null)
                {
                    logger.LogError("ObjectId {userObjectId} was null", userObjectId);
                    return Results.NotFound("Workouts could not be found");
                }

                var workouts = await _workoutService.GetAllWorkouts(userObjectId);

                if (workouts == null)
                {
                    logger.LogError("No workouts found for user {userObjectId}", userObjectId);
                    return Results.NoContent();
                }

                logger.LogInformation("Returned all workouts");
                return Results.Ok(workouts);
            }).WithTags("Workout");

            app.MapGet("/workouts/{userObjectId}/byDate", async (IWorkoutService _workoutService,
                string userObjectId,
                DateTime date,
                ILogger<Program> logger) =>
            {
                if (userObjectId == null)
                {
                    logger.LogError("ObjectId {userObjectId} was null", userObjectId);
                    return Results.NotFound("Workouts could not be found");
                }

                var workouts = await _workoutService.GetWorkoutsByDate(userObjectId, date);

                if (workouts == null)
                {
                    logger.LogError("No workouts found for user {userObjectId} on date {date}", userObjectId, date);
                    return Results.NoContent();
                }

                logger.LogInformation("Returned all workouts for user {userObjectId} on date {date}", userObjectId, date);
                return Results.Ok(workouts);
            }).WithTags("Workout");

            app.MapGet("/workouts/{userObjectId}/byMonth", async (IWorkoutService _workoutService,
                string userObjectId,
                DateTime month,
                ILogger<Program> logger) =>
            {
                if (userObjectId == null)
                {
                    logger.LogError("ObjectId {userObjectId} was null", userObjectId);
                    return Results.NotFound("Workouts could not be found");
                }
                var workouts = await _workoutService.GetWorkoutDataByMonth(userObjectId, month);

                if (workouts == null)
                {
                    logger.LogError("No workouts could be found for user {userObjectId} and month {month}", userObjectId, month);
                    return Results.NoContent();
                }

                logger.LogInformation("Returned list of workouts for user {userObjectId} and {month}", userObjectId, month);
                return Results.Ok(workouts);
            }).WithTags("Workout");

            app.MapGet("/workouts/{workoutId:int}", async (IWorkoutService _workoutService,
                int workoutId,
                string userObjectId,
                ILogger<Program> logger) =>
            {
                if (workoutId < 1)
                {
                    logger.LogError("WorkoutId {workoutId} could not be found", workoutId);
                    return Results.NotFound("Workout could not be found");
                }

                var workout = await _workoutService.GetWorkoutById(workoutId, userObjectId);

                if (workout == null)
                {
                    logger.LogError("Workout {workout} could not be found for user {userObjectId} and workout {workoutId}", workout, userObjectId, workoutId);
                    return Results.NoContent();
                }

                logger.LogInformation("Returned {workout.Id} for user {userObjectId} and workoutId {workoutId}", workout.Id, userObjectId, workoutId);
                return Results.Ok(workout);
            }).WithTags("Workout");


            app.MapGet("/workouts/{userObjectId}/statistics/categories", async (IWorkoutService _workoutService, string userObjectId, DateTime month, ILogger<Program> logger) =>
            {
                if (userObjectId == null)
                {
                    logger.LogError("ObjectId {userObjectId} was null", userObjectId);
                    return Results.BadRequest("Workouts could not be found");
                }

                var workouts = await _workoutService.GetWorkoutCountByCategory(userObjectId, month);
                if (workouts == null)
                {
                    logger.LogError("Workouts could not be found for user {userObjectId}", userObjectId);
                    return Results.NoContent();
                }

                logger.LogInformation("Returned for user {userObjectId}", userObjectId);
                return Results.Ok(workouts);
            }).WithTags("Workout");

            app.MapGet("/workouts/{userObjectId}/statistics/duration-per-category", async (IWorkoutService _workoutService, string userObjectId, DateTime month, ILogger<Program> logger) =>
            {
                if (userObjectId == null)
                {
                    logger.LogError("ObjectId {userObjectId} was null", userObjectId);
                    return Results.NotFound("Workouts could not be found");
                }

                var result = await _workoutService.GetDurationByCategory(userObjectId, month);
                if (result == null)
                {
                    logger.LogError("Workouts could not be found for user {userObjectId}", userObjectId);
                    return Results.NoContent();
                }
                logger.LogInformation("Returned for user {userObjectId}", userObjectId);
                return Results.Ok(result);

            }).WithTags("Workout");


            app.MapPost("/workouts", async (IWorkoutService _workoutService,
                CreateWorkoutDto workout,
                ILogger<Program> logger) =>
            {
                if (workout == null)
                {
                    logger.LogError("Workout {workout} was null", workout);
                    return Results.BadRequest("Workout could not be created");
                }

                var creationSuccessful = await _workoutService.CreateWorkout(workout);

                if (creationSuccessful)
                {
                    logger.LogInformation("Workout {workout.Title} was created successfully", workout.Title);
                    return Results.Created("Workout successfully created", creationSuccessful);
                }

                logger.LogInformation("Workout {workout.Title} could not be created", workout.Title);
                return Results.BadRequest("Workout could not be created");
            }).WithTags("Workout");

            app.MapDelete("/workouts/{workoutId:int}", async (IWorkoutService _workoutService,
                int workoutId,
                ILogger<Program> logger) =>
            {
                if (workoutId < 1)
                {
                    logger.LogError("No workout with id {workoutId} exists", workoutId);
                    return Results.NotFound("Workout could not be found");
                }

                var deletionSuccessful = await _workoutService.DeleteWorkout(workoutId);

                if (deletionSuccessful)
                {
                    logger.LogInformation("Workout {workoutId} was successfully deleted", workoutId);
                    return Results.Ok("Workout successfully deleted");
                }

                logger.LogError("Workout {workoutId} could not be deleted", workoutId);
                return Results.BadRequest("Workout could not be deleted");
            }).WithTags("Workout");
            
            app.MapGet("/workout/{userObjectId}/upcoming", async (IWorkoutService _workoutService,
               string userObjectId,
               ILogger<Program> logger) =>
            {
                if (userObjectId == null)
                {
                    logger.LogError("ObjectId {userObjectId} was null", userObjectId);
                    return Results.NotFound("Workouts could not be found");

                }

                var workout = await _workoutService.GetUpcomingWorkout(userObjectId)!;

                if (workout == null)
                {
                    logger.LogError("No upcoming workout found for user {userObjectId}", userObjectId);
                    return Results.NoContent();
                }

                logger.LogInformation("Returned upcoming workout");
                return Results.Ok(workout);
            }).WithTags("Workout");
        }
    }
}
