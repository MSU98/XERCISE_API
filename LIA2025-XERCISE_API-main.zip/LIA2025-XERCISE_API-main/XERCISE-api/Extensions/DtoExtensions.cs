﻿namespace xerciseAPI.Extensions
{
    public static class CategoryDtoExtensions
    {
        public static CategoryDTO ToDto(this Category category)
        {
            return new CategoryDTO
            {
                Id = category.Id,
                WorkoutCategory = category.WorkoutCategory
            };
        }
        public static List<CategoryDTO> ToDtoList(this IEnumerable<Category> categories)
        {
            return [.. categories.Select(c => c.ToDto())];
        }
    }
    public static class IntensityDtoExtensions
    {
        public static IntensityDTO ToDto(this Intensity intensity)
        {
            return new IntensityDTO
            {
                Id = intensity.Id,
                IntensityGrade = intensity.IntensityGrade
            };
        }
        public static List<IntensityDTO> ToDtoList(this IEnumerable<Intensity> intensities)
        {
            return [.. intensities.Select(i => i.ToDto())];
        }
    }
    public static class UserResponseDtoExtensions
    {
        public static UserResponse ToDto(this User user)
        {
            return new UserResponse
            {
                Id = user.Id,
                ObjectId = user.ObjectId,
                Email = user.Email!,
                Name = user.Name!,
                RefreshToken = user.RefreshToken
            };
        }
        public static List<UserResponse> ToDtoList(this IEnumerable<User> users)
        {
            return [.. users.Select(u => u.ToDto())];
        }
    }
    public static class WorkoutResponseDtoExtensions
    {
        public static WorkoutResponse ToDto(this Workout workout)
        {
            return new WorkoutResponse
            {
                Id = workout.Id,
                Title = workout.Title,
                Category = workout.Category.WorkoutCategory,
                Activity = workout.Activity,
                Intensity = workout.Intensity.IntensityGrade,
                Duration = workout.Duration,
                Date = workout.Date
            };
        }
        public static List<WorkoutResponse> ToDtoList(this IEnumerable<Workout> workouts)
        {
            return [.. workouts.Select(w => w.ToDto())];
        }
    }
    public static class StepGoalDtoExtensions
    {
        public static StepGoalDTO ToDto(this StepGoal stepGoal)
        {
            return new StepGoalDTO
            {
                Id = stepGoal.Id,
                Goal = stepGoal.Goal
            };
        }
    }
    public static class StepEntryDtoExtensions
    {
        public static StepEntryDTO ToDto(this StepEntry stepEntry)
        {
            return new StepEntryDTO
            {
                Id = stepEntry.Id,
                Steps = stepEntry.Steps
            };
        }
    }
}