﻿namespace xerciseAPI.Models;

public partial class Category
{
    public int Id { get; set; }

    public string WorkoutCategory { get; set; } = null!;

    public virtual ICollection<Workout> Workouts { get; set; } = new List<Workout>();
}
