﻿namespace xerciseAPI.Models.DTOs
{
    public class CategoryDTO
    {
        public int Id { get; set; }
        public int Count { get; set; }
        public string? WorkoutCategory { get; set; } 
    }
}
