﻿public class CreateWorkoutDto
{
    public int Id { get; set; }

    public string? Title { get; set; }

    public int CategoryId { get; set; }

    public string? Activity { get; set; }

    public int IntensityId { get; set; }

    public int? Duration { get; set; }

    public DateTime Date { get; set; } = DateTime.Now;

    public string? ObjectId { get; set; }

}