﻿namespace xerciseAPI.Models.DTOs
{
    public class IntensityDTO
    {
        public int Id { get; set; }

        public string? IntensityGrade { get; set; }
    }
}
