﻿
namespace xerciseAPI.Models.DTOs
{
    public class StepEntryDTO
    {
        public int Id { get; set; }
        public int Steps { get; set; }
    }
}