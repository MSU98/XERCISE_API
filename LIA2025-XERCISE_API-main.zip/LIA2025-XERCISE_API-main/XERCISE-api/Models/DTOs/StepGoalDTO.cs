﻿namespace xerciseAPI.Models.DTOs
{
    public class StepGoalDTO
    {
        public int Id { get; set; }
        public int Goal { get; set; }
    }
}