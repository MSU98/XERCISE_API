﻿namespace xerciseAPI.Models.DTOs
{
    public class StepProgressDTO
    {
        public int Steps { get; set; }
        public int StepGoal { get; set; }
    }
}