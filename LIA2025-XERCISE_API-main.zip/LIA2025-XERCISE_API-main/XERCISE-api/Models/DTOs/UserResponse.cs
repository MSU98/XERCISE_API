﻿using System.Text.Json.Serialization;

namespace xerciseAPI.Models.DTOs
{
    public class UserResponse
    {
        public int Id { get; set; }

        [JsonPropertyName("objectId")]
        public string? ObjectId { get; set; }

        [JsonPropertyName("email")]
        public required string Email { get; set; }

        [JsonPropertyName("name")]
        public required string Name { get; set; }
        public RefreshToken? RefreshToken { get; set; }
    }
}
