﻿public class WorkoutData
    {
        public string? Category { get; set; }

        public int? Duration { get; set; }

        public DateTime Date { get; set; }
    }
