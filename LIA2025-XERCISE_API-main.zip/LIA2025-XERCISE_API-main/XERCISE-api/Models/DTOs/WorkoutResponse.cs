﻿public class WorkoutResponse
{
    public int Id { get; set; }

    public string? Title { get; set; }

    public string? Category { get; set; }

    public string? Activity { get; set; }

    public string? Intensity { get; set; }

    public int? Duration { get; set; }

    public DateTime Date { get; set; } = DateTime.Now;

}