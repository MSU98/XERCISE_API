﻿namespace xerciseAPI.Models;

public partial class Intensity
{
    public int Id { get; set; }

    public string IntensityGrade { get; set; } = null!;

    public virtual ICollection<Workout> Workouts { get; set; } = new List<Workout>();
}
