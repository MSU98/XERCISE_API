﻿namespace xerciseAPI.Models;
public partial class StepGoal
{
    public int Id { get; set; }
    public int Goal { get; set; } = 0;
    public int UserId { get; set; }
    public virtual User User { get; set; } = null!;
}