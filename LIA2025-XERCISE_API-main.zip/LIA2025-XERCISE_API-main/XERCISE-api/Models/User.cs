﻿namespace xerciseAPI.Models;
public partial class User
{
    public int Id { get; set; }

    public string? ObjectId { get; set; }

    public string? Email { get; set; }

    public string? Name { get; set; }
    public RefreshToken? RefreshToken { get; set; }
    public virtual ICollection<Workout> Workouts { get; set; } = new List<Workout>();
}
