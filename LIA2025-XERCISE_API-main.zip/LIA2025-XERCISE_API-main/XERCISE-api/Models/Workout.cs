﻿namespace xerciseAPI.Models;

public partial class Workout
{
    public int Id { get; set; }

    public string? Title { get; set; }

    public int CategoryId { get; set; }

    public string? Activity { get; set; }

    public int IntensityId { get; set; }

    public int? Duration { get; set; }

    public DateTime Date { get; set; } = DateTime.Now;

    public int UserId { get; set; }

    public virtual Category Category { get; set; } = null!;

    public virtual Intensity Intensity { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
