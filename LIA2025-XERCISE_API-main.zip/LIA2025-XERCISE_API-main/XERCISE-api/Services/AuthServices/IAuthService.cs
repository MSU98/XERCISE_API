﻿namespace xerciseAPI.Services.AuthServices
{
    public interface IAuthService
    {
        string CreateToken(UserResponse user);
        RefreshToken GenerateRefreshToken();
    }
}
