﻿using xerciseAPI.Extensions;

namespace xerciseAPI.Services.CategoryServices
{
    public class CategoryService : ICategoryService
    {
        private readonly IDatabase _db;
        private readonly CategoryValidator _validator = new CategoryValidator();

        public CategoryService(IDatabase db)
        {
            _db = db;
        }

        public List<CategoryDTO> GetAllCategories()
        {
            return _db.Categories.ToList().ToDtoList();
        }

        public CategoryDTO GetCategoryById(int categoryId)
        {
            var category = _db.Categories.FirstOrDefault(x => x.Id == categoryId);
            if (category == null)
                return null!;

            return category.ToDto();
        }

        public async Task<bool> CreateCategory(string workoutCategory)
        {
            if (String.IsNullOrEmpty(workoutCategory)) return false;

            var category = new Category()
            {
                WorkoutCategory = workoutCategory,
                Workouts = new List<Workout>()
            };

            var result = _validator.Validate(category);

            if (result.IsValid)
            {
                _db.Categories.Add(category);
                await _db.SaveChangesAsync();

                return true;
            }

            return false;

        }

        public async Task<bool> DeleteCategory(int categoryId)
        {
            var category = _db.Categories.FirstOrDefault(c => c.Id == categoryId);

            if (category == null) 
                return false;

            _db.Categories.Remove(category);
            await _db.SaveChangesAsync();

            return true;
        }

        public async Task<bool> UpdateCategory(int categoryId, string workoutCategory)
        {
            var category = _db.Categories.FirstOrDefault(c => c.Id == categoryId);
            if (category == null) 
                return false;

            category.WorkoutCategory = workoutCategory;

            var result = _validator.Validate(category);

            if (result.IsValid)
            {
                await _db.SaveChangesAsync();
                return true;
            }

            return false;
        }
    }
}
