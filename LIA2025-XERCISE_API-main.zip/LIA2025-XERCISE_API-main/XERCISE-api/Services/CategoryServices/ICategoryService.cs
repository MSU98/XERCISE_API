﻿namespace xerciseAPI.Services.CategoryServices
{
    public interface ICategoryService
    {
        List<CategoryDTO> GetAllCategories();
        CategoryDTO GetCategoryById(int categoryId);
        Task<bool> CreateCategory(string workoutCategory);
        Task<bool> DeleteCategory(int categoryId);
        Task<bool> UpdateCategory(int categoryId, string workoutCategory);
    }
}
