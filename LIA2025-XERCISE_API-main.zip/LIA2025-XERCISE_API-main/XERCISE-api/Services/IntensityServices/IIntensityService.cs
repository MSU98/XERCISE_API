﻿namespace xerciseAPI.Services.IntensityServices
{
    public interface IIntensityService
    {
        List<IntensityDTO> GetAllIntensities();
        IntensityDTO? GetIntensityById(int intensityId);
        Task<bool> CreateIntensity(string intensityGrade);
        Task<bool> DeleteIntensity(int intensityId);
        Task<bool> UpdateIntensity(int intensityId, string intensityInput);
    }
}
