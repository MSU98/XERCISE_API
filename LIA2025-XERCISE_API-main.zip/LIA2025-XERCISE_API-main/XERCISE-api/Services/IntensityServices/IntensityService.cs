﻿using xerciseAPI.Extensions;

namespace xerciseAPI.Services.IntensityServices
{
    public class IntensityService : IIntensityService
    {
        private readonly IDatabase _db;
        public IntensityService(IDatabase db)
        {
            _db = db;
        }

        public List<IntensityDTO> GetAllIntensities()
        {
            return _db.Intensities.ToList().ToDtoList();
        }

        public IntensityDTO? GetIntensityById(int intensityId)
        {
            var intensity = _db.Intensities.FirstOrDefault(x => x.Id == intensityId);

            if ( intensity == null) 
                return null;


            return intensity.ToDto();
        }

        public async Task<bool> CreateIntensity(string intensityGrade)
        {
            if (intensityGrade == null) 
                return false;

            var intensity = new Intensity()
            {
                IntensityGrade = intensityGrade,
                Workouts = new List<Workout>()
            };

            var validator = new IntensityValidator();
            var result = validator.Validate(intensity);
            if (result.IsValid)
            {
                _db.Intensities.Add(intensity);
                await _db.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<bool> DeleteIntensity(int intensityId)
        {
            var intensity = _db.Intensities.FirstOrDefault(x => x.Id == intensityId);
            if (intensity == null) 
                return false;

            _db.Intensities.Remove(intensity);
            await _db.SaveChangesAsync();

            return true;
        }

        public async Task<bool> UpdateIntensity(int intensityId, string intensityInput)
        {
            var intensity = _db.Intensities.FirstOrDefault(x => x.Id == intensityId);

            if(intensity == null) 
                return false;

            intensity.IntensityGrade = intensityInput;

            var validator = new IntensityValidator();
            var result = validator.Validate(intensity);
            if (result.IsValid)
            {

                await _db.SaveChangesAsync();

                return true;
            }

            return false;
        }
    }
}
