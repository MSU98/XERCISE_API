﻿namespace xerciseAPI.Services.StepEntryServices
{
    public interface IStepEntryService
    {
        Task<bool> SaveStepsOnDate(string objectId, int stepsToAdd, DateTime date);
        Task<bool> DeleteStepsOnDate(string objectId, DateTime date);
        Task<StepEntryDTO> GetSteps(string objectId, DateTime date);
    }
}