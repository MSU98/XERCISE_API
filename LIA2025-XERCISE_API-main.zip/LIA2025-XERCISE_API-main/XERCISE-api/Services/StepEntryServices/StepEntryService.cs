using xerciseAPI.Models;

namespace xerciseAPI.Services.StepEntryServices
{
    public class StepEntryService : IStepEntryService
    {
        private readonly IDatabase _db;
        public StepEntryService(IDatabase db)
        {
            _db = db;
        }
        public async Task<bool> SaveStepsOnDate(string objectId, int stepsToAdd, DateTime date)
        {
            if (objectId == null || stepsToAdd <= 0) return false;

            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == objectId);
            if (user == null) return false;

            var existing = await _db.StepEntries.FirstOrDefaultAsync(s => s.UserId == user.Id && s.Date == date);
            if (existing != null) 
            {
                existing.Steps += stepsToAdd;
            }
            else 
            { 
                _db.StepEntries.Add(new StepEntry
                {
                    UserId = user.Id,
                    Date = date,
                    Steps = stepsToAdd
                });
            }
            await _db.SaveChangesAsync();
            return true;
        }
        public async Task<bool> DeleteStepsOnDate(string objectId, DateTime date)
        {
            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == objectId);
            if (user == null) return false;

            var existing =  await _db.StepEntries.FirstOrDefaultAsync(s => s.UserId == user.Id && s.Date == date); 
            if (existing == null) return false;

            _db.StepEntries.Remove(existing);
            await _db.SaveChangesAsync();
            return true;
        }
        public async Task<StepEntryDTO> GetSteps(string objectId, DateTime date)
        {
            if (objectId == null) return null;

            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == objectId);
            if (user == null) return null;

            var result = await _db.StepEntries.FirstOrDefaultAsync(s => s.UserId == user.Id && s.Date == date);
            if (result == null) return null;

            return result.ToDto();
        }
    }
}