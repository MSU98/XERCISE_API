﻿namespace xerciseAPI.Services.StepGoalServices
{
    public interface IStepGoalService
    {
        Task<bool> SaveStepGoal(string objectId, int stepGoal);
        Task<StepGoalDTO?> GetStepGoal(string objectId);
        Task<bool> DeleteStepGoal(string objectId);
        Task<StepProgressDTO> GetStepProgressByDate(string objectId, DateTime date);
    }
}