﻿using xerciseAPI.Models.DTOs;

namespace xerciseAPI.Services.StepGoalServices
{
    public class StepGoalService : IStepGoalService
    {
        private readonly IDatabase _db;
        public StepGoalService(IDatabase db)
        {
            _db = db;
        }
        public async Task<bool> SaveStepGoal (string userObjectId, int stepGoal)
        {
            if (stepGoal < 0 || String.IsNullOrEmpty(userObjectId)) return false;

            var user = await GetUserByObjectId(userObjectId);
            if (user == null) return false;

            var userExists = await _db.Users.AnyAsync(u => u.Id == user.Id);
            if (!userExists) return false;

            var existing = await _db.StepGoals.FirstOrDefaultAsync(g => g.UserId == user.Id);
            if (existing != null)
            {
                existing.Goal = stepGoal; 
            }
            else {
                _db.StepGoals.Add(new StepGoal
                {
                    UserId = user.Id,
                    Goal = stepGoal
                });
            }

            await _db.SaveChangesAsync();
            return true;
        }
        public async Task<StepGoalDTO?> GetStepGoal(string userObjectId)
        {
            if (String.IsNullOrEmpty(userObjectId)) return null;

            var user = await GetUserByObjectId(userObjectId);
            if (user == null) return null;

            var result = await _db.StepGoals.FirstOrDefaultAsync(g => g.UserId == user.Id);
            if (result == null) return null;

            return result!.ToDto();
        }
        public async Task<bool> DeleteStepGoal (string userObjectId)
        {
            if (String.IsNullOrEmpty(userObjectId)) return false;

            var user = await GetUserByObjectId(userObjectId);
            if (user == null) return false;

            var existing = await _db.StepGoals.FirstOrDefaultAsync(g => g.UserId == user.Id);
            if (existing == null) return false;

            _db.StepGoals.Remove(existing);
            await _db.SaveChangesAsync();
            return true;
        }
        public async Task<StepProgressDTO> GetStepProgressByDate(string userObjectId, DateTime date)
        {
            if (String.IsNullOrEmpty(userObjectId)) return null;

            var user = await GetUserByObjectId(userObjectId); ;
            if (user == null) return null;

            var goal = await _db.StepGoals.FirstOrDefaultAsync(g => g.UserId == user.Id);
            var stepEntry = await _db.StepEntries
                .FirstOrDefaultAsync(e => e.UserId == user.Id && e.Date.Date == date.Date);

            return new StepProgressDTO
            {
                Steps = stepEntry?.Steps ?? 0,
                StepGoal = goal?.Goal ?? 0
            };
        }
        private async Task<User> GetUserByObjectId(string userObjectId)
        {
            return await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == userObjectId);
        }
    }
}
