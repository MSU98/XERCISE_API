﻿namespace xerciseAPI.Services.UserService
{
    public interface IUserService
    {
        Task<List<UserResponse>?> GetAllUsers();
        Task<bool> CreateUser(UserResponse user);
        Task<bool> DeleteUser(int userId);
        Task<bool> UpdateUser(UserResponse inputUser);
        Task<UserResponse?> GetUserById(string objectId);
        Task SaveRefreshToken(string objectId, RefreshToken refreshToken);
        Task<UserResponse?> GetUserByRefreshToken(string token);
    }
}
