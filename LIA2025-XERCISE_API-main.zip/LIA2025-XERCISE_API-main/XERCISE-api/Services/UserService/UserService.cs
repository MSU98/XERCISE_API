﻿using xerciseAPI.Extensions;

namespace xerciseAPI.Services.UserService
{
    public class UserService(IDatabase db) : IUserService
    {
        private readonly IDatabase _db = db;

        public async Task<bool> CreateUser(UserResponse inputUser)
        {
            var validator = new UserValidator();
            var result = validator.Validate(inputUser);
            if (result.IsValid)
            {
                var user = new User
                {
                    ObjectId = inputUser.ObjectId,
                    Email = inputUser.Email,
                    Name = inputUser.Name
                };

                _db.Users.Add(user);
                await _db.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<bool> DeleteUser(int userId)
        {
            var user = _db.Users.FirstOrDefault(x => x.Id == userId);
            if (user != null)
            {
                _db.Users.Remove(user);
                await _db.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<List<UserResponse>?> GetAllUsers()
        {
            var users = await _db.Users.ToListAsync();
            return users.ToDtoList();
        }

        public async Task<UserResponse?> GetUserById(string objectId)
        {
            var user = await _db.Users.FirstOrDefaultAsync(x => x.ObjectId == objectId);
            if (user == null) 
                return null;

            return user.ToDto();
        }

        public async Task<bool> UpdateUser(UserResponse inputUser)
        {

            if (inputUser == null) 
                return false;
            var validator = new UserValidator();

            var user = await GetUserById(inputUser.ObjectId!);

            if (user == null) 
                return false;

            user.Email = inputUser.Email!;
            user.Name = inputUser.Name!;

            var result = validator.Validate(user);
            if (result.IsValid)
            {
                await _db.SaveChangesAsync();
                return true;
            }
            return false;
        }
        /*-----------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                                     RefreshTokens
       -----------------------------------------------------------------------------------------------------------------------------------------------------------*/

        public async Task SaveRefreshToken(string objectId, RefreshToken refreshToken)
        {
            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == objectId);

            if (user == null)
                throw new Exception("User not found");

            user.RefreshToken = refreshToken;

            await _db.SaveChangesAsync();
        }

        public async Task<UserResponse?> GetUserByRefreshToken(string token)
        {
            if (String.IsNullOrEmpty(token)) return null;

            var user = await _db.Users.Where(u => u.RefreshToken!.Token == token && u.RefreshToken.Expires > DateTime.UtcNow).FirstOrDefaultAsync();
            if (user == null) return null;

            return user!.ToDto();
        }
    }
}
