﻿namespace xerciseAPI.Services.WorkoutServices
{
    public interface IWorkoutService
    {
        Task<List<WorkoutResponse>?> GetAllWorkouts(string objectId);
        Task<List<WorkoutData>?> GetWorkoutDataByMonth(string objectId, DateTime month);
        Task<List<WorkoutResponse>?> GetWorkoutsByDate(string objectId, DateTime date);
        Task<List<CategoryDTO>?> GetWorkoutCountByCategory(string objectId, DateTime month);
        Task<List<WorkoutData>?> GetDurationByCategory(string objectId, DateTime month);
        Task<WorkoutResponse?> GetWorkoutById(int id, string objectId);
        Task<bool> CreateWorkout(CreateWorkoutDto workout);
        Task<bool> DeleteWorkout(int id);
        Task<WorkoutResponse>? GetUpcomingWorkout(string userObjectId, DateTime? now = null);
    }
}
