﻿using System;
using xerciseAPI.Extensions;

namespace xerciseAPI.Services.WorkoutServices
{
    public class WorkoutService : IWorkoutService
    {
        private readonly IDatabase _db;

        public WorkoutService(IDatabase db)
        {
            _db = db;
        }

        public async Task<List<WorkoutResponse>?> GetAllWorkouts(string objectId)
        {
         
            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == objectId);
            if (user == null)
                return null;

            var workouts = await _db.Workouts
                .Include(c => c.Category)
                .Include(i => i.Intensity)
                .Where(x => x.UserId == user.Id).ToListAsync();
            if (workouts.IsNullOrEmpty())
                return null;

            return workouts.ToDtoList();
        }
        public async Task<List<WorkoutData>?> GetWorkoutDataByMonth(string objectId, DateTime month)
        {
            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == objectId);
            if (user == null)
                return null;

            var workouts = await _db.Workouts.Include(c => c.Category).Where(x => x.UserId == user.Id && x.Date.Month == month.Month && x.Date.Year == month.Year).OrderBy(x => x.Date).ToListAsync();
            if (workouts.IsNullOrEmpty())
                return null;

            return ConvertToWorkoutData(workouts);
        }

        public async Task<List<CategoryDTO>?> GetWorkoutCountByCategory(string objectId, DateTime month)
        {
            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == objectId);
            if (user == null)
                return null;

            var workoutByCategory = await _db.Workouts
                .Include(w => w.Category)
                .Where(w => w.UserId == user.Id &&
                            w.Date.Month == month.Month &&
                            w.Date.Year == month.Year)
                .GroupBy(w => w.Category.WorkoutCategory)
                .Select(c => new CategoryDTO
                {
                    WorkoutCategory = c.Key,
                    Count = c.Count()
                })
                .ToListAsync();

            return workoutByCategory;
        }

        public async Task<List<WorkoutData>?>GetDurationByCategory(string objectId, DateTime month)
        {
            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == objectId);
            if (user == null)
                return null;

            var totalDurationByCategory = await _db.Workouts
                .Include(w => w.Category)
                .Where(w => w.UserId == user.Id &&
                            w.Date.Month == month.Month &&
                            w.Date.Year == month.Year)
                .GroupBy(w => w.Category.WorkoutCategory)
                .Select(x => new WorkoutData
                {
                    Category = x.Key,
                    Duration = x.Sum(w => w.Duration), 
                    Date = month
                })
                .ToListAsync();
            return totalDurationByCategory;

        }

        public async Task<List<WorkoutResponse>?> GetWorkoutsByDate(string objectId, DateTime date)
        {
            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == objectId);
            if (user == null)
                return null;

            var workouts = await _db.Workouts
                .Include(c => c.Category)
                .Include(i => i.Intensity)
                .Where(x => x.UserId == user.Id && x.Date.Date == date.Date).ToListAsync();
            if (workouts.IsNullOrEmpty())
                return null;

            return workouts.ToDtoList();
        }

        public async Task<WorkoutResponse?> GetWorkoutById(int id, string objectId)
        {
            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == objectId);
            if (user == null) return null;

            var workout = await _db.Workouts
                .Include(c => c.Category)
                .Include(i => i.Intensity)
                .FirstOrDefaultAsync(x => x.Id == id && x.UserId == user.Id);
            if (workout == null) return null;

            return workout!.ToDto();
        }

        public async Task<bool> CreateWorkout(CreateWorkoutDto inputWorkout)
        {
            if (inputWorkout == null)
                return false;

            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == inputWorkout.ObjectId);
            if (user == null) return false;

            var validator = new WorkoutValidator();
            var result = validator.Validate(inputWorkout);

            if (result.IsValid)
            {
                var workout = new Workout
                {
                    Title = inputWorkout.Title,
                    CategoryId = inputWorkout.CategoryId,
                    Activity = inputWorkout.Activity,
                    IntensityId = inputWorkout.IntensityId,
                    Duration = inputWorkout.Duration,
                    Date = inputWorkout.Date,
                    UserId = user.Id
                };
                _db.Workouts.Add(workout);
                await _db.SaveChangesAsync();
                return true;
            }

            return false!;
        }

        public async Task<bool> DeleteWorkout(int id)
        {
            var workout = _db.Workouts.FirstOrDefault(x => x.Id == id);
            if (workout != null)
            {
                _db.Workouts.Remove(workout);
                await _db.SaveChangesAsync();
                return true;
            }
            return false;
        }
        public async Task<WorkoutResponse>? GetUpcomingWorkout(string userObjectId, DateTime? now = null)
        {

            var currentDate = now ?? DateTime.Now;

            var user = await _db.Users.FirstOrDefaultAsync(u => u.ObjectId == userObjectId);
            if (user == null) return null;

            var workout = await _db.Workouts
                .Include(c => c.Category)
                .Include(i => i.Intensity)
                .Where(w => w.UserId == user.Id && w.Date > currentDate)
                .OrderBy(w => w.Date)
                .FirstOrDefaultAsync();

            if (workout == null) return null;

            return workout!.ToDto();
        }

        /*-----------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                                       Responses
         -----------------------------------------------------------------------------------------------------------------------------------------------------------*/

        public List<WorkoutData>? ConvertToWorkoutData(List<Workout> workouts)
        {
            if (workouts == null)
                return null;

            var workoutDataList = new List<WorkoutData>();
            foreach (Workout workout in workouts)
            {

                var workoutData = new WorkoutData
                {
                    Category = workout.Category.WorkoutCategory,
                    Duration = workout.Duration,
                    Date = workout.Date
                };

                workoutDataList.Add(workoutData);
            }

            return workoutDataList;
        }
    }
}
