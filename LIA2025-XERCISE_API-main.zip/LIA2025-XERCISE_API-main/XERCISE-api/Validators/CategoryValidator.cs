﻿namespace xerciseAPI.Validators
{
    public class CategoryValidator : AbstractValidator<Category>
    {
        public CategoryValidator() 
        {
            RuleFor(x => x.WorkoutCategory).NotEmpty().NotNull().MaximumLength(50);
        }
    }
}
