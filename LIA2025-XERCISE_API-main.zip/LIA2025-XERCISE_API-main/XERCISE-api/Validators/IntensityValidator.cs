﻿namespace xerciseAPI.Validators
{
    public class IntensityValidator : AbstractValidator<Intensity>
    {
        public IntensityValidator() 
        {
            RuleFor(x => x.IntensityGrade).NotEmpty().NotNull().MaximumLength(50);
        }
    }
}
