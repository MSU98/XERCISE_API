﻿namespace xerciseAPI.Validators
{
    public class UserValidator : AbstractValidator<UserResponse>
    {
        public UserValidator()
        {
            RuleFor(x => x.ObjectId).NotEmpty().NotNull();
            RuleFor(x => x.Email).NotEmpty().NotNull().MaximumLength(100);
            RuleFor(x => x.Name).NotEmpty().NotNull().MaximumLength(50);
        }
    }
}
