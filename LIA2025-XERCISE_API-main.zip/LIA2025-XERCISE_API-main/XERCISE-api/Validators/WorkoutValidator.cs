﻿namespace xerciseAPI.Validators
{
    public class WorkoutValidator : AbstractValidator<CreateWorkoutDto>
    {
        public WorkoutValidator()
        {
            RuleFor(x => x.Title).NotEmpty().NotNull().MaximumLength(50);
            RuleFor(x => x.CategoryId).NotEmpty().NotNull().GreaterThan(0);
            RuleFor(x => x.Activity).NotEmpty().MaximumLength(250);
            RuleFor(x => x.IntensityId).NotEmpty().GreaterThan(0);
            RuleFor(x => x.Duration).GreaterThan(0).NotEmpty();
            RuleFor(x => x.Date).NotEmpty().NotNull();
            RuleFor(x => x.ObjectId).NotEmpty().NotNull();
        }
    }
}
